import typing
from typing import TYPE_CHECKING, List

import pandas as pd
from pycelonis.pql.pql_debugger import PQLDebugger
from pycelonis.pql.pql_parser import PQLParser
from pycelonis.service.pql_language.service import PqlQueryType
from pycelonis_core.utils.errors import PyCelonisHTTPStatusError, PyCelonisValueError
from saolapy.pql.base import PQL, PQLColumn, PQLFilter
from saolapy.saola_connector import SaolaConnector

if TYPE_CHECKING:
    from pycelonis.ems import DataModel
    from pycelonis.ems.apps.content_node.analysis import PublishedAnalysis
    from pycelonis.ems.studio.content_node.knowledge_model import KnowledgeModel


def verify_columns(data_model: "DataModel", columns: List[PQLColumn]) -> None:
    """Verifies given columns."""
    for col in columns:
        error_messages = PQLDebugger.debug(data_model.client, data_model.id, col.query, PqlQueryType.DIMENSION)
        if error_messages:
            raise ValueError(f"Errors in column '{col.name}':\n\n" + "\n\n\n".join(error_messages))


def verify_filters(data_model: "DataModel", filters: List[PQLFilter]) -> None:
    """Verifies given filters."""
    for filter_ in filters:
        error_messages = PQLDebugger.debug(data_model.client, data_model.id, filter_.query, PqlQueryType.FILTER)
        if error_messages:
            raise ValueError("Errors in filter:\n\n" + "\n\n\n".join(error_messages))


class DataModelSaolaConnector(SaolaConnector):
    """Data model saola connector."""

    def __init__(self, data_model: "DataModel"):
        self.data_model = data_model

    def _export_data(self, query: PQL) -> pd.DataFrame:
        """Exports given PQL as data frame."""
        return self.data_model._export_data_frame(query)

    def verify_query(self, query: PQL) -> None:
        """Verifies given query."""
        verify_columns(self.data_model, query.columns)
        verify_filters(self.data_model, query.filters)

    def convert_filter_to_expressions(self, filter_: PQLFilter) -> List[str]:
        """Converts given pql filter to conditional expressions.

        Args:
            filter_: PQL filter to convert.

        Returns:
            Conditional expressions resulting from pql filter.
        """
        return PQLParser.convert_filter_to_expressions(self.data_model.client, self.data_model.id, filter_.query)


class KnowledgeModelSaolaConnector(SaolaConnector):
    """Knowledge model saola connector."""

    def __init__(self, data_model: "DataModel", knowledge_model: "KnowledgeModel"):
        self.data_model = data_model
        self.knowledge_model = knowledge_model

    def _export_data(self, query: PQL, **kwargs: typing.Any) -> pd.DataFrame:
        """Exports given PQL as data frame."""
        data_query, query_environment = self.knowledge_model._resolve_query(query, **kwargs)
        return self.data_model._export_data_frame(data_query, query_environment)

    def verify_query(self, query: PQL) -> None:
        """Verifies given query."""
        # Currently not supported by PQL service due to KPIs and variables

    def convert_filter_to_expressions(self, filter_: PQLFilter) -> List[str]:
        """Converts given pql filter to conditional expressions.

        Args:
            filter_: PQL filter to convert.

        Returns:
            Conditional expressions resulting from pql filter.
        """
        filter_list = []
        try:
            filter_list += PQLParser.convert_filter_to_expressions(
                self.data_model.client, self.data_model.id, filter_.query
            )
        except PyCelonisHTTPStatusError as e:
            if e.message is not None and e.message.find("400 Bad Request"):
                raise PyCelonisValueError(
                    "Complex filters (containing e.g. KPIs) are not supported with the KnowledgeModelSaolaConnector."
                    "Please, remove the filter or use the DataModelSaolaConnector instead."
                ) from e
            raise e
        return filter_list


class AnalysisSaolaConnector(SaolaConnector):
    """Analysis saola connector."""

    def __init__(
        self,
        data_model: "DataModel",
        analysis: "PublishedAnalysis",
    ):
        self.data_model = data_model
        self.analysis = analysis

    def _export_data(self, query: PQL) -> pd.DataFrame:
        """Exports given PQL as data frame."""
        data_query, query_environment = self.analysis._resolve_query(query)
        return self.data_model._export_data_frame(data_query, query_environment)

    def verify_query(self, query: PQL) -> None:
        """Verifies given query."""
        # Currently not supported by PQL service due to KPIs and variables

    def convert_filter_to_expressions(self, filter_: PQLFilter) -> List[str]:
        """Converts given pql filter to conditional expressions.

        Args:
            filter_: PQL filter to convert.

        Returns:
            Conditional expressions resulting from pql filter.
        """
        filter_list = []
        try:
            filter_list += PQLParser.convert_filter_to_expressions(
                self.data_model.client, self.data_model.id, filter_.query
            )
        except PyCelonisHTTPStatusError as e:
            if e.message is not None and e.message.find("400 Bad Request"):
                raise PyCelonisValueError(
                    "Complex filters (containing e.g. variables and KPIs) are not supported with the "
                    "AnalysisSaolaConnector. Please, remove the filter or use the DataModelSaolaConnector instead."
                ) from e
            raise e
        return filter_list
