import logging
from datetime import datetime
from io import BytesIO
from typing import Any, Dict, List, Literal, Optional, Union

from pycelonis_core.base.base_model import (PyCelonisBaseEnum,
                                            PyCelonisBaseModel)
from pycelonis_core.client.client import Client
from pycelonis_core.utils.ml_workbench import TRACKING_LOGGER

try:
    from pydantic.v1 import (Field, StrictBool, StrictInt,  # type: ignore
                             StrictStr)
except ImportError:
    from pydantic import (Field, StrictBool, StrictInt,  # type: ignore
                          StrictStr)


logger = logging.getLogger(TRACKING_LOGGER)


JsonNode = Any


class BoardAssetType(PyCelonisBaseEnum):
    BOARD = "BOARD"
    BOARD_V2 = "BOARD_V2"


class InputDataType(PyCelonisBaseEnum):
    TEXT = "TEXT"
    NUMBER = "NUMBER"
    BOOLEAN = "BOOLEAN"
    PQL = "PQL"
    LIST = "LIST"
    DATE = "DATE"
    OBJECT = "OBJECT"


class InputScope(PyCelonisBaseEnum):
    USER_SPECIFIC = "USER_SPECIFIC"
    SYSTEM = "SYSTEM"


class ContentNodeType(PyCelonisBaseEnum):
    ASSET = "ASSET"
    PACKAGE = "PACKAGE"
    FOLDER = "FOLDER"
    IMAGE = "IMAGE"


class CascadeType(PyCelonisBaseEnum):
    DELETE = "DELETE"


class RelationType(PyCelonisBaseEnum):
    USES = "USES"
    DEPENDS_ON = "DEPENDS_ON"


class BoardUpsertRequest(PyCelonisBaseModel):
    board_asset_type: Optional['BoardAssetType'] = Field(alias="boardAssetType")
    configuration: Optional['str'] = Field(alias="configuration")
    id: Optional['str'] = Field(alias="id")
    input_variable_definitions: Optional['List[Optional[InputVariableDefinitionTransport]]'] = Field(
        alias="inputVariableDefinitions"
    )
    parent_node_id: Optional['str'] = Field(alias="parentNodeId")
    parent_node_key: Optional['str'] = Field(alias="parentNodeKey")
    root_node_key: Optional['str'] = Field(alias="rootNodeKey")


class InputVariableDefinitionTransport(PyCelonisBaseModel):
    data_type: Optional['InputDataType'] = Field(alias="dataType")
    default_value: Optional['str'] = Field(alias="defaultValue")
    description: Optional['str'] = Field(alias="description")
    display_name: Optional['str'] = Field(alias="displayName")
    key: Optional['str'] = Field(alias="key")
    propagate: Optional['bool'] = Field(alias="propagate")
    scope: Optional['InputScope'] = Field(alias="scope")


class ExceptionReference(PyCelonisBaseModel):
    message: Optional['str'] = Field(alias="message")
    reference: Optional['str'] = Field(alias="reference")
    short_message: Optional['str'] = Field(alias="shortMessage")


class ContentNodeTransport(PyCelonisBaseModel):
    activated_draft_id: Optional['str'] = Field(alias="activatedDraftId")
    asset: Optional['bool'] = Field(alias="asset")
    asset_metadata_transport: Optional['AssetMetadataTransport'] = Field(alias="assetMetadataTransport")
    asset_type: Optional['str'] = Field(alias="assetType")
    auto_publish: Optional['bool'] = Field(alias="autoPublish")
    base: Optional['ContentNodeBaseTransport'] = Field(alias="base")
    change_date: Optional['datetime'] = Field(alias="changeDate")
    created_by_id: Optional['str'] = Field(alias="createdById")
    creation_date: Optional['datetime'] = Field(alias="creationDate")
    deleted_at: Optional['datetime'] = Field(alias="deletedAt")
    deleted_by: Optional['str'] = Field(alias="deletedBy")
    draft_id: Optional['str'] = Field(alias="draftId")
    embeddable: Optional['bool'] = Field(alias="embeddable")
    id: Optional['str'] = Field(alias="id")
    identifier: Optional['str'] = Field(alias="identifier")
    input_variable_definitions: Optional['List[Optional[InputVariableDefinitionTransport]]'] = Field(
        alias="inputVariableDefinitions"
    )
    invalid_content: Optional['bool'] = Field(alias="invalidContent")
    key: Optional['str'] = Field(alias="key")
    name: Optional['str'] = Field(alias="name")
    node_type: Optional['ContentNodeType'] = Field(alias="nodeType")
    object_id: Optional['str'] = Field(alias="objectId")
    order: Optional['int'] = Field(alias="order")
    parent_node_id: Optional['str'] = Field(alias="parentNodeId")
    parent_node_key: Optional['str'] = Field(alias="parentNodeKey")
    permissions: Optional['List[Optional[str]]'] = Field(alias="permissions")
    public_available: Optional['bool'] = Field(alias="publicAvailable")
    root: Optional['bool'] = Field(alias="root")
    root_node_id: Optional['str'] = Field(alias="rootNodeId")
    root_node_key: Optional['str'] = Field(alias="rootNodeKey")
    root_with_key: Optional['str'] = Field(alias="rootWithKey")
    schema_version: Optional['int'] = Field(alias="schemaVersion")
    serialization_type: Optional['str'] = Field(alias="serializationType")
    serialized_content: Optional['str'] = Field(alias="serializedContent")
    show_in_viewer_mode: Optional['bool'] = Field(alias="showInViewerMode")
    source: Optional['str'] = Field(alias="source")
    space_id: Optional['str'] = Field(alias="spaceId")
    tenant_id: Optional['str'] = Field(alias="tenantId")
    updated_by: Optional['str'] = Field(alias="updatedBy")
    working_draft_id: Optional['str'] = Field(alias="workingDraftId")


class FrontendHandledBackendError(PyCelonisBaseModel):
    error_information: Optional['Any'] = Field(alias="errorInformation")
    frontend_error_key: Optional['str'] = Field(alias="frontendErrorKey")


class AssetMetadataTransport(PyCelonisBaseModel):
    asset_usages: Optional['List[Optional[AssetUsage]]'] = Field(alias="assetUsages")
    hidden: Optional['bool'] = Field(alias="hidden")
    metadata: Optional['JsonNode'] = Field(alias="metadata")
    related_assets: Optional['List[Optional[RelatedAsset]]'] = Field(alias="relatedAssets")
    used_variables: Optional['List[Optional[VariableDefinition]]'] = Field(alias="usedVariables")


class AssetUsage(PyCelonisBaseModel):
    object_id: Optional['str'] = Field(alias="objectId")
    target_objects: Optional['List[Optional[TargetUsageMetadata]]'] = Field(alias="targetObjects")


class TargetUsageMetadata(PyCelonisBaseModel):
    id: Optional['str'] = Field(alias="id")
    source_objects: Optional['List[Optional[SourceUsageMetadata]]'] = Field(alias="sourceObjects")
    type_: Optional['str'] = Field(alias="type")


class SourceUsageMetadata(PyCelonisBaseModel):
    id: Optional['str'] = Field(alias="id")


class VariableDefinition(PyCelonisBaseModel):
    description: Optional['str'] = Field(alias="description")
    key: Optional['str'] = Field(alias="key")
    metadata: Optional['JsonNode'] = Field(alias="metadata")
    runtime: Optional['bool'] = Field(alias="runtime")
    source: Optional['str'] = Field(alias="source")
    type_: Optional['str'] = Field(alias="type")


class ContentNodeBaseTransport(PyCelonisBaseModel):
    external: Optional['bool'] = Field(alias="external")
    reference: Optional['str'] = Field(alias="reference")
    version: Optional['str'] = Field(alias="version")


class RelatedAsset(PyCelonisBaseModel):
    cascade_type: Optional['CascadeType'] = Field(alias="cascadeType")
    object_id: Optional['str'] = Field(alias="objectId")
    relation_type: Optional['RelationType'] = Field(alias="relationType")
    type_: Optional['str'] = Field(alias="type")


BoardUpsertRequest.update_forward_refs()
InputVariableDefinitionTransport.update_forward_refs()
ExceptionReference.update_forward_refs()
ContentNodeTransport.update_forward_refs()
FrontendHandledBackendError.update_forward_refs()
AssetMetadataTransport.update_forward_refs()
AssetUsage.update_forward_refs()
TargetUsageMetadata.update_forward_refs()
SourceUsageMetadata.update_forward_refs()
VariableDefinition.update_forward_refs()
ContentNodeBaseTransport.update_forward_refs()
RelatedAsset.update_forward_refs()


class Blueprint:
    @staticmethod
    def post_api_boards(
        client: Client,
        request_body: BoardUpsertRequest,
        should_activate: Optional['bool'] = None,
        should_publish: Optional['bool'] = None,
        validate_: Optional['bool'] = None,
        **kwargs: Any,
    ) -> ContentNodeTransport:
        logger.debug(
            f"Request: 'POST' -> '/blueprint/api/boards'",
            extra={
                "request_type": "POST",
                "path": "/blueprint/api/boards",
                "tracking_type": "API_REQUEST",
            },
        )

        params: Dict[str, Any] = {}
        if should_activate is not None:
            if isinstance(should_activate, PyCelonisBaseModel):
                params.update(should_activate.json_dict(by_alias=True))
            elif isinstance(should_activate, dict):
                params.update(should_activate)
            else:
                params["shouldActivate"] = should_activate
        if should_publish is not None:
            if isinstance(should_publish, PyCelonisBaseModel):
                params.update(should_publish.json_dict(by_alias=True))
            elif isinstance(should_publish, dict):
                params.update(should_publish)
            else:
                params["shouldPublish"] = should_publish
        if validate_ is not None:
            if isinstance(validate_, PyCelonisBaseModel):
                params.update(validate_.json_dict(by_alias=True))
            elif isinstance(validate_, dict):
                params.update(validate_)
            else:
                params["validate"] = validate_
        return client.request(
            method="POST",
            url=f"/blueprint/api/boards",
            params=params,
            request_body=request_body,
            parse_json=True,
            type_=ContentNodeTransport,
            **kwargs,
        )

    @staticmethod
    def put_api_boards_board_id(
        client: Client,
        board_id: str,
        request_body: BoardUpsertRequest,
        should_activate: Optional['bool'] = None,
        should_publish: Optional['bool'] = None,
        validate_: Optional['bool'] = None,
        **kwargs: Any,
    ) -> ContentNodeTransport:
        logger.debug(
            f"Request: 'PUT' -> '/blueprint/api/boards/{board_id}'",
            extra={
                "request_type": "PUT",
                "path": "/blueprint/api/boards/{board_id}",
                "tracking_type": "API_REQUEST",
            },
        )

        params: Dict[str, Any] = {}
        if should_activate is not None:
            if isinstance(should_activate, PyCelonisBaseModel):
                params.update(should_activate.json_dict(by_alias=True))
            elif isinstance(should_activate, dict):
                params.update(should_activate)
            else:
                params["shouldActivate"] = should_activate
        if should_publish is not None:
            if isinstance(should_publish, PyCelonisBaseModel):
                params.update(should_publish.json_dict(by_alias=True))
            elif isinstance(should_publish, dict):
                params.update(should_publish)
            else:
                params["shouldPublish"] = should_publish
        if validate_ is not None:
            if isinstance(validate_, PyCelonisBaseModel):
                params.update(validate_.json_dict(by_alias=True))
            elif isinstance(validate_, dict):
                params.update(validate_)
            else:
                params["validate"] = validate_
        return client.request(
            method="PUT",
            url=f"/blueprint/api/boards/{board_id}",
            params=params,
            request_body=request_body,
            parse_json=True,
            type_=ContentNodeTransport,
            **kwargs,
        )
