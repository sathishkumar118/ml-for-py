"""SaolaPy module for interaction with SaolaDB."""
