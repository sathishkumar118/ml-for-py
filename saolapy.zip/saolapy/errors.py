class DataExportFailedError(RuntimeError):
    """Error raised for failed data exports."""
