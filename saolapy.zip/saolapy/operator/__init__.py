"""Module for PQL operators."""
import abc
from abc import abstractmethod
from typing import Any


class PQLOperator(abc.ABC):
    """Interface for all PQLOperator."""

    is_boolean: bool = False

    @property
    @abstractmethod
    def query_string(self) -> str:
        """Returns query string of given PQLOperator."""

    def __eq__(self, other: Any) -> bool:
        if not isinstance(other, PQLOperator):
            return False
        return self.query_string == other.query_string

    def __repr__(self) -> str:
        return self.query_string
