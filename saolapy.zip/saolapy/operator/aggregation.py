from typing import Union

from saolapy.operator import PQLOperator
from saolapy.operator.arithmetic import AddOperator, IsNullOperator, SubtractOperator
from saolapy.operator.base import UnaryPQLOperator
from saolapy.operator.scalar import FloatPQLOperator
from saolapy.types import ScalarValue


class SumOperator(UnaryPQLOperator):
    """Sum operator that computes sum of column.

    Applies [SUM operator](https://docs.celonis.com/en/sum.html) to column.
    """

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"SUM( {self._operand.query_string} )"


class AvgOperator(UnaryPQLOperator):
    """Mean operator that computes mean of column.

    Applies [AVG operator](https://docs.celonis.com/en/avg.html) to column.
    """

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"AVG( {self._operand.query_string} )"


class ProductOperator(UnaryPQLOperator):
    """Product operator that computes product of column.

    Applies [PRODUCT operator](https://docs.celonis.com/en/product.html) to column.
    """

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"PRODUCT( {self._operand.query_string} )"


class MedianOperator(UnaryPQLOperator):
    """Median operator that computes median of column.

    Applies [MEDIAN operator](https://docs.celonis.com/en/median.html) to column.
    """

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"MEDIAN( {self._operand.query_string} )"


class QuantileOperator(UnaryPQLOperator):
    """Quantile operator that computes quantile of column.

    Applies [QUANTILE operator](https://docs.celonis.com/en/quantile.html) to column.
    """

    def __init__(self, operand: Union["ScalarValue", PQLOperator], quantile: float) -> None:
        """Initializes QuantileOperator.

        Args:
            operand: Operand for which quantile is computed.
            quantile: Quantile to compute.
        """
        super().__init__(operand)
        self._quantile = FloatPQLOperator(quantile)

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"QUANTILE( {self._operand.query_string}, {self._quantile.query_string} )"


class ModeOperator(UnaryPQLOperator):
    """Mode operator that computes mode of column.

    Applies [MODE operator](https://docs.celonis.com/en/mode.html) to column.
    """

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"MODE( {self._operand.query_string} )"


class MaxOperator(UnaryPQLOperator):
    """Max operator that computes max of column.

    Applies [MAX operator](https://docs.celonis.com/en/max.html) to column.
    """

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"MAX( {self._operand.query_string} )"


class MinOperator(UnaryPQLOperator):
    """Min operator that computes min of column.

    Applies [MIN operator](https://docs.celonis.com/en/min.html) to column.
    """

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"MIN( {self._operand.query_string} )"


class CountOperator(UnaryPQLOperator):
    """Operator that computes count of values in series excluding null values.

    Applies [COUNT operator](https://docs.celonis.com/en/count.html) to column.
    """

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"""COUNT( {self._operand.query_string} )"""


class CountNullOperator(UnaryPQLOperator):
    """Operator that computes count of values in series including null values."""

    @property
    def query_string(self) -> str:
        """Returns query string."""
        operator = CountOperator(IsNullOperator(self._operand))
        return operator.query_string


class CountDistinctOperator(UnaryPQLOperator):
    """Operator that computes distinct count of values in series excluding null values.

    Applies [COUNT DISTINCT operator](https://docs.celonis.com/en/count-distinct.html) to column.
    """

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"""COUNT( DISTINCT {self._operand.query_string} )"""


class CountDistinctNullOperator(UnaryPQLOperator):
    """Operator that computes distinct count of values in series including null values."""

    @property
    def query_string(self) -> str:
        """Returns query string."""
        operator = AddOperator(CountDistinctOperator(self._operand), MaxOperator(IsNullOperator(self._operand)))
        return operator.query_string


class IsUniqueOperator(UnaryPQLOperator):
    """Operator that computes whether column only contains unique rows."""

    @property
    def query_string(self) -> str:
        """Returns query string."""
        count_distinct_null_operator = CountDistinctNullOperator(self._operand)
        count_null_operator = CountNullOperator(self._operand)
        subtract_operator = SubtractOperator(count_null_operator, count_distinct_null_operator)

        return f"( CASE WHEN {subtract_operator.query_string} > 0 THEN 0 ELSE 1 END )"


class VarianceOperator(UnaryPQLOperator):
    """Variance operator that computes variance of column.

    Applies [VAR operator](https://docs.celonis.com/en/var.html) to column.
    """

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"VAR( {self._operand.query_string} )"


class StandardDeviationOperator(UnaryPQLOperator):
    """Standard deviation operator that computes standard deviation of column.

    Applies [STDEV operator](https://docs.celonis.com/en/stdev.html) to column.
    """

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"STDEV( {self._operand.query_string} )"
