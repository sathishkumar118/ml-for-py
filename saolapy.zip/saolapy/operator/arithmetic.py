from typing import Union

from saolapy.operator import PQLOperator
from saolapy.operator.base import BinaryPQLOperator, UnaryPQLOperator
from saolapy.operator.scalar import IntegerPQLOperator
from saolapy.types import ScalarValue


class IsNullOperator(UnaryPQLOperator):
    """Computes whether values are null.

    Applies [ISNULL operator](https://docs.celonis.com/en/isnull.html) to column.
    """

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"ISNULL( {self._operand.query_string} )"


class AddOperator(BinaryPQLOperator):
    """Add operator that adds all operands.

    Applies [ADD operator](https://docs.celonis.com/en/add.html) to column.
    """

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"( {self._lhs_operand.query_string} + {self._rhs_operand.query_string} )"


class SubtractOperator(BinaryPQLOperator):
    """Subtraction operator that subtracts all operands.

    Applies [SUB operator](https://docs.celonis.com/en/sub.html) to column.
    """

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"( {self._lhs_operand.query_string} - {self._rhs_operand.query_string} )"


class MultiplyOperator(BinaryPQLOperator):
    """Multiply operator that multiplies all operands.

    Applies [MULT operator](https://docs.celonis.com/en/mult.html) to column.
    """

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"( {self._lhs_operand.query_string} * {self._rhs_operand.query_string} )"


class DivideOperator(BinaryPQLOperator):
    """Divide operator that divides all operands.

    Applies [DIV operator](https://docs.celonis.com/en/div.html) to column.
    """

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"( {self._lhs_operand.query_string} / {self._rhs_operand.query_string} )"


class ModuloOperator(BinaryPQLOperator):
    """Modulo operator that takes modulo of all operands.

    Applies [MODULO operator](https://docs.celonis.com/en/modulo.html) to column.
    """

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"( {self._lhs_operand.query_string} % {self._rhs_operand.query_string} )"


class FloorDivisionOperator(BinaryPQLOperator):
    """Floor division operator that applies floor division to all operands.

    Applies [FLOOR operator](https://docs.celonis.com/en/floor.html) and
    [DIV operator](https://docs.celonis.com/en/div.html) to column.
    """

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"FLOOR( {self._lhs_operand.query_string} / {self._rhs_operand.query_string} )"


class PowerOperator(BinaryPQLOperator):
    """Power operator that raises the left operand to the power of the right operand.

    Applies [POWER operator](https://docs.celonis.com/en/power.html) to column.
    """

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"POWER( {self._lhs_operand.query_string}, {self._rhs_operand.query_string} )"


class AbsOperator(UnaryPQLOperator):
    """Operator that computes the absolute value of a series.

    Applies [ABS operator](https://docs.celonis.com/en/abs.html) to column.
    """

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"ABS( {self._operand.query_string} )"


class InverseOperator(UnaryPQLOperator):
    """Operator that computes the inverse value of a series.

    Applies [INVERSE operator](https://docs.celonis.com/en/inverse.html) to column.
    """

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"INVERSE( {self._operand.query_string} )"


class RoundOperator(UnaryPQLOperator):
    """Operator that rounds the  value of a series.

    Applies [ROUND operator](https://docs.celonis.com/en/round.html) to column.
    """

    def __init__(self, operand: Union["ScalarValue", PQLOperator], decimals: int = 0) -> None:
        """Initializes RoundOperator.

        Args:
            operand: Operand to which round operator is applied.
            decimals: Number of decimals.
        """
        super().__init__(operand)
        self._decimals = IntegerPQLOperator(decimals)

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"ROUND( {self._operand.query_string}, {self._decimals.query_string} )"
