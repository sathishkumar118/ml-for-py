from abc import ABC
from typing import TYPE_CHECKING, Any, Union

from saolapy.operator import PQLOperator
from saolapy.operator.scalar import ScalarPQLOperatorFactory
from saolapy.pql.base import PQLColumn

if TYPE_CHECKING:
    from saolapy.types import ScalarValue


class QueryStringPQLOperator(PQLOperator):
    """PQLOperator for simple query string inputs."""

    def __init__(self, query_string: Union[str, PQLColumn]):
        """Initialises QueryStringPQLOperator with given query string."""
        if isinstance(query_string, str):
            self._query_string = query_string
        elif isinstance(query_string, PQLColumn):
            self._query_string = query_string.query
        else:
            raise TypeError(f"Data type {type(query_string)} not supported for `QueryStringPQLOperator`.")

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return self._query_string


class UnaryPQLOperator(PQLOperator, ABC):
    """Base class for all unary PQLOperator."""

    def __init__(self, operand: Union["ScalarValue", PQLOperator], **_: Any) -> None:
        self._operand: PQLOperator = (
            operand if isinstance(operand, PQLOperator) else ScalarPQLOperatorFactory.get_operator(operand)
        )


class BinaryPQLOperator(PQLOperator, ABC):
    """Base class for all binary PQLOperator."""

    def __init__(
        self, lhs_operand: Union["ScalarValue", PQLOperator], rhs_operand: Union["ScalarValue", PQLOperator], **_: Any
    ) -> None:
        self._lhs_operand: PQLOperator = (
            lhs_operand if isinstance(lhs_operand, PQLOperator) else ScalarPQLOperatorFactory.get_operator(lhs_operand)
        )
        self._rhs_operand: PQLOperator = (
            rhs_operand if isinstance(rhs_operand, PQLOperator) else ScalarPQLOperatorFactory.get_operator(rhs_operand)
        )
