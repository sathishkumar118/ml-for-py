from typing import List, Union

from saolapy.operator import PQLOperator
from saolapy.operator.base import BinaryPQLOperator, UnaryPQLOperator
from saolapy.operator.scalar import ScalarPQLOperatorFactory
from saolapy.types import ScalarValue


class LowerThanOperator(BinaryPQLOperator):
    """Lower than operator.

    Applies [LOWER_THAN operator](https://docs.celonis.com/en/comparison-operators.html) to column.
    """

    is_boolean: bool = True

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"( {self._lhs_operand.query_string} < {self._rhs_operand.query_string} )"


class LowerEqualsOperator(BinaryPQLOperator):
    """Lower or equals operator.

    Applies [LOWER_EQUALS operator](https://docs.celonis.com/en/comparison-operators.html) to column.
    """

    is_boolean: bool = True

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"( {self._lhs_operand.query_string} <= {self._rhs_operand.query_string} )"


class EqualsOperator(BinaryPQLOperator):
    """Equals operator.

    Applies [EQUALS operator](https://docs.celonis.com/en/comparison-operators.html) to column.
    """

    is_boolean: bool = True

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"( {self._lhs_operand.query_string} = {self._rhs_operand.query_string} )"


class NotEqualsOperator(BinaryPQLOperator):
    """Not equals operator.

    Applies [NOT_EQUALS operator](https://docs.celonis.com/en/comparison-operators.html) to column.
    """

    is_boolean: bool = True

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"( {self._lhs_operand.query_string} != {self._rhs_operand.query_string} )"


class GreaterEqualsOperator(BinaryPQLOperator):
    """Greater or equals operator.

    Applies [GREATER_EQUALS operator](https://docs.celonis.com/en/comparison-operators.html) to column.
    """

    is_boolean: bool = True

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"( {self._lhs_operand.query_string} >= {self._rhs_operand.query_string} )"


class GreaterThanOperator(BinaryPQLOperator):
    """Greater than operator.

    Applies [GREATER_THAN operator](https://docs.celonis.com/en/comparison-operators.html) to column.
    """

    is_boolean: bool = True

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"( {self._lhs_operand.query_string} > {self._rhs_operand.query_string} )"


class AndOperator(BinaryPQLOperator):
    """And operator.

    Applies [AND operator](https://docs.celonis.com/en/and.html) to column.
    """

    is_boolean: bool = True

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"( {self._lhs_operand.query_string} AND {self._rhs_operand.query_string} )"


class OrOperator(BinaryPQLOperator):
    """Or operator.

    Applies [OR operator](https://docs.celonis.com/en/or.html) to column.
    """

    is_boolean: bool = True

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"( {self._lhs_operand.query_string} OR {self._rhs_operand.query_string} )"


class NotOperator(UnaryPQLOperator):
    """Not operator.

    Applies [NOT operator](https://docs.celonis.com/en/not.html) to column.
    """

    is_boolean: bool = True

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"NOT ( {self._operand.query_string} )"


class IsNullOperator(UnaryPQLOperator):
    """Computes whether values are null.

    Applies [IS NULL operator](https://docs.celonis.com/en/is-null.html) to column.
    """

    is_boolean: bool = True

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"""( {self._operand.query_string} IS NULL )"""


class IsInOperator(UnaryPQLOperator):
    """Is in operator.

    Applies [IN operator](https://docs.celonis.com/en/in.html) to column.
    """

    is_boolean = True

    def __init__(
        self, operand: Union["ScalarValue", PQLOperator], values: List[Union["ScalarValue", PQLOperator]]
    ) -> None:
        """Initializes IsInOperator.

        Args:
            operand: Operand for which is checked if it's in values.
            values: Values to check whether they contain operand.
        """
        super().__init__(operand)
        self._values: List[PQLOperator] = [
            value if isinstance(value, PQLOperator) else ScalarPQLOperatorFactory.get_operator(value)
            for value in values
        ]

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"( {self._operand.query_string} IN ( {', '.join([value.query_string for value in self._values])} ) )"


class BetweenOperator(UnaryPQLOperator):
    """Between operator.

    Applies [BETWEEN operator](https://docs.celonis.com/en/between.html) to column.
    """

    is_boolean = True

    def __init__(self, operand: Union["ScalarValue", PQLOperator], left: "ScalarValue", right: "ScalarValue") -> None:
        """Initializes BetweenOperator.

        Args:
            operand: Operand for which is checked if it fulfills left <= operand <= right.
            left: Left boundary.
            right: Right boundary.
        """
        super().__init__(operand)
        self._left = ScalarPQLOperatorFactory.get_operator(left)
        self._right = ScalarPQLOperatorFactory.get_operator(right)

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"( {self._operand.query_string} BETWEEN {self._left.query_string} AND {self._right.query_string} )"
