from typing import Optional, Union

from saolapy.operator import PQLOperator
from saolapy.operator.base import UnaryPQLOperator
from saolapy.operator.scalar import StringPQLOperator
from saolapy.types import ScalarValue


class ToIntOperator(UnaryPQLOperator):
    """To int operator that converts column to int.

    Applies [TO_INT operator](https://docs.celonis.com/en/to_int.html) to column.
    """

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"TO_INT( {self._operand.query_string} )"


class ToFloatOperator(UnaryPQLOperator):
    """To float operator that converts column to float.

    Applies [TO_FLOAT operator](https://docs.celonis.com/en/to_float.html) to column.
    """

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"TO_FLOAT( {self._operand.query_string} )"


class ToStringOperator(UnaryPQLOperator):
    """To string operator that converts column to string.

    Applies [TO_STRING operator](https://docs.celonis.com/en/to_string.html) to column.
    """

    def __init__(self, operand: Union["ScalarValue", PQLOperator], format_: Optional[str] = None) -> None:
        """Initializes ToStringOperator.

        Args:
            operand: Operand which is converted to string.
            format_: Format defining how dates are interpreted
                [documentation](https://docs.celonis.com/en/to_date.html).
        """
        super().__init__(operand)
        self._format = StringPQLOperator(format_) if format_ is not None else None

    @property
    def query_string(self) -> str:
        """Returns query string."""
        if self._format is not None:
            return f"TO_STRING( {self._operand.query_string}, FORMAT( {self._format.query_string} ) )"
        return f"TO_STRING( {self._operand.query_string} )"


class ToDateOperator(UnaryPQLOperator):
    """To date operator that converts column to date.

    Applies [TO_DATE operator](https://docs.celonis.com/en/to_date.html) to column.
    """

    def __init__(self, operand: Union["ScalarValue", PQLOperator], format_: str) -> None:
        """Initializes ToDateOperator.

        Args:
            operand: Operand which is converted to date.
            format_: Format defining how string is interpreted
                [documentation](https://docs.celonis.com/en/to_date.html).
        """
        super().__init__(operand)
        self._format = StringPQLOperator(format_) if format_ is not None else None

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"TO_DATE( {self._operand.query_string}, FORMAT( {self._format} ) )"
