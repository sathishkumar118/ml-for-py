from saolapy.operator.base import UnaryPQLOperator


class YearOperator(UnaryPQLOperator):
    """Year operator that returns year of datetime column.

    Applies [YEAR operator](https://docs.celonis.com/en/year.html) to column.
    """

    @property
    def query_string(self) -> str:
        return f"YEAR( {self._operand.query_string} )"


class QuarterOperator(UnaryPQLOperator):
    """Quarter operator that returns the quarter.

    Applies [QUARTER operator](https://docs.celonis.com/en/quarter.html) to column.
    """

    @property
    def query_string(self) -> str:
        return f"QUARTER( {self._operand.query_string} )"


class MonthOperator(UnaryPQLOperator):
    """Month operator that returns month of datetime column.

    Applies [MONTH operator](https://docs.celonis.com/en/month.html) to column.
    """

    @property
    def query_string(self) -> str:
        return f"MONTH( {self._operand.query_string} )"


class CalendarWeekOperator(UnaryPQLOperator):
    """Calendar week operator that returns calendar week of datetime column.

    Applies [CALENDAR_WEEK operator](https://docs.celonis.com/en/calendar_week.html) to column.
    """

    @property
    def query_string(self) -> str:
        return f"CALENDAR_WEEK( {self._operand.query_string} )"


class DayOperator(UnaryPQLOperator):
    """Day operator that returns day of datetime column.

    Applies [DAY operator](https://docs.celonis.com/en/day.html) to column.
    """

    @property
    def query_string(self) -> str:
        return f"DAY( {self._operand.query_string} )"


class HoursOperator(UnaryPQLOperator):
    """Hours operator that returns hours of datetime column.

    Applies [HOURS operator](https://docs.celonis.com/en/hours.html) to column.
    """

    @property
    def query_string(self) -> str:
        return f"HOURS( {self._operand.query_string} )"


class MinutesOperator(UnaryPQLOperator):
    """Minutes operator that returns minutes of datetime column.

    Applies [MINUTES operator](https://docs.celonis.com/en/minutes.html) to column.
    """

    @property
    def query_string(self) -> str:
        return f"MINUTES( {self._operand.query_string} )"


class SecondsOperator(UnaryPQLOperator):
    """Seconds operator that returns seconds of datetime column.

    Applies [SECONDS operator](https://docs.celonis.com/en/seconds.html) to column.
    """

    @property
    def query_string(self) -> str:
        return f"SECONDS( {self._operand.query_string} )"


class DayOfWeekOperator(UnaryPQLOperator):
    """Day of week operator that returns day of week as number.

    Applies [DAY_OF_WEEK operator](https://docs.celonis.com/en/day_of_week.html) to column.
    """

    @property
    def query_string(self) -> str:
        return f"DAY_OF_WEEK( {self._operand.query_string} )"


class RoundYearOperator(UnaryPQLOperator):
    """Round year operator that rounds date to year.

    Applies [ROUND_YEAR operator](https://docs.celonis.com/en/round_year.html) to column.
    """

    @property
    def query_string(self) -> str:
        return f"ROUND_YEAR( {self._operand.query_string} )"


class RoundQuarterOperator(UnaryPQLOperator):
    """Round quarter operator that rounds date to quarter.

    Applies [ROUND_QUARTER operator](https://docs.celonis.com/en/round_quarter.html) to column.
    """

    @property
    def query_string(self) -> str:
        return f"ROUND_QUARTER( {self._operand.query_string} )"


class RoundMonthOperator(UnaryPQLOperator):
    """Round month operator that rounds date to month.

    Applies [ROUND_MONTH operator](https://docs.celonis.com/en/round_month.html) to column.
    """

    @property
    def query_string(self) -> str:
        return f"ROUND_MONTH( {self._operand.query_string} )"


class RoundWeekOperator(UnaryPQLOperator):
    """Round week operator that rounds date to week.

    Applies [ROUND_WEEK operator](https://docs.celonis.com/en/round_week.html) to column.
    """

    @property
    def query_string(self) -> str:
        return f"ROUND_WEEK( {self._operand.query_string} )"


class RoundDayOperator(UnaryPQLOperator):
    """Round day operator that rounds date to day.

    Applies [ROUND_DAY operator](https://docs.celonis.com/en/round_day.html) to column.
    """

    @property
    def query_string(self) -> str:
        return f"ROUND_DAY( {self._operand.query_string} )"


class RoundHourOperator(UnaryPQLOperator):
    """Round hour operator that rounds date to hour.

    Applies [ROUND_HOUR operator](https://docs.celonis.com/en/round_hour.html) to column.
    """

    @property
    def query_string(self) -> str:
        return f"ROUND_HOUR( {self._operand.query_string} )"


class RoundMinuteOperator(UnaryPQLOperator):
    """Round minute operator that rounds date to minute.

    Applies [ROUND_MINUTE operator](https://docs.celonis.com/en/round_minute.html) to column.
    """

    @property
    def query_string(self) -> str:
        return f"ROUND_MINUTE( {self._operand.query_string} )"


class RoundSecondOperator(UnaryPQLOperator):
    """Round second operator that rounds date to second.

    Applies [ROUND_SECOND operator](https://docs.celonis.com/en/round_second.html) to column.
    """

    @property
    def query_string(self) -> str:
        return f"ROUND_SECOND( {self._operand.query_string} )"
