from abc import ABC
from typing import Optional, Union

from saolapy.operator import PQLOperator
from saolapy.operator.base import UnaryPQLOperator
from saolapy.types import ScalarValue


class PullUpOperator(UnaryPQLOperator, ABC):
    """Base class for pull up operators."""

    pu_function: str

    def __init__(
        self,
        operand: Union["ScalarValue", PQLOperator],
        target_table: str,
        filter_expression: Optional[str] = None,
    ) -> None:
        """Initializes PullUpOperator.

        Args:
            operand: Operand to which pull up function is applied.
            target_table: The table to which the aggregation result should be pulled.
            filter_expression: An optional filter expression to specify which values of the source table should
                be taken into account for the aggregation.
        """
        super().__init__(operand)
        self._target_table: str = target_table
        self._filter_expression: Optional[str] = filter_expression

    @property
    def query_string(self) -> str:
        """Returns query string."""
        if self._filter_expression is None:
            return f"{self.pu_function}( {self._target_table}, {self._operand.query_string} )"
        return f"{self.pu_function}( {self._target_table}, {self._operand.query_string}, {self._filter_expression} )"


class PullUpAvgOperator(PullUpOperator):
    """Pull up operator that computes mean of column.

    Applies [PU_AVG operator](https://docs.celonis.com/en/pu_avg.html) to column.
    """

    pu_function: str = "PU_AVG"


class PullUpSumOperator(PullUpOperator):
    """Pull up operator that computes sum of column.

    Applies [PU_SUM operator](https://docs.celonis.com/en/pu_sum.html) to column.
    """

    pu_function: str = "PU_SUM"


class PullUpProductOperator(PullUpOperator):
    """Pull up operator that computes product of column.

    Applies [PU_PRODUCT operator](https://docs.celonis.com/en/pu_product.html) to column.
    """

    pu_function: str = "PU_PRODUCT"


class PullUpCountOperator(PullUpOperator):
    """Pull up operator that computes count of column.

    Applies [PU_COUNT operator](https://docs.celonis.com/en/pu_count.html) to column.
    """

    pu_function: str = "PU_COUNT"


class PullUpCountDistinctOperator(PullUpOperator):
    """Pull up operator that computes distinct counts of column.

    Applies [PU_COUNT_DISTINCT operator](https://docs.celonis.com/en/pu_count_distinct.html) to column.
    """

    pu_function: str = "PU_COUNT_DISTINCT"


class PullUpMinOperator(PullUpOperator):
    """Pull up operator that computes min of column.

    Applies [PU_MIN operator](https://docs.celonis.com/en/pu_min.html) to column.
    """

    pu_function: str = "PU_MIN"


class PullUpMaxOperator(PullUpOperator):
    """Pull up operator that computes max of column.

    Applies [PU_MAX operator](https://docs.celonis.com/en/pu_max.html) to column.
    """

    pu_function: str = "PU_MAX"


class PullUpMedianOperator(PullUpOperator):
    """Pull up operator that computes median of column.

    Applies [PU_MEDIAN operator](https://docs.celonis.com/en/pu_median.html) to column.
    """

    pu_function: str = "PU_MEDIAN"


class PullUpModeOperator(PullUpOperator):
    """Pull up operator that computes mode of column.

    Applies [PU_MODE operator](https://docs.celonis.com/en/pu_mode.html) to column.
    """

    pu_function: str = "PU_MODE"


class PullUpStandardDeviationOperator(PullUpOperator):
    """Pull up operator that computes standard deviation of column.

    Applies [PU_STDEV operator](https://docs.celonis.com/en/pu_stdev.html) to column.
    """

    pu_function: str = "PU_STDEV"
