from saolapy.operator import PQLOperator
from saolapy.operator.scalar import IntegerPQLOperator


class RangeOperator(PQLOperator):
    """Operator for range query."""

    def __init__(self, start: int, step: int) -> None:
        """Initialises RangeOperator with given start and step."""
        self._start = IntegerPQLOperator(start)
        self._step = IntegerPQLOperator(step)

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"{self._start.query_string} - {self._step.query_string} + RUNNING_TOTAL({self._step.query_string})"
