from datetime import datetime

from saolapy.operator import PQLOperator
from saolapy.types import ScalarValue


class StringPQLOperator(PQLOperator):
    """PQLOperator for string values."""

    def __init__(self, string: str):
        """Initialises StringPQLOperator with given value."""
        self._string = string

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"'{self._string}'"


class IntegerPQLOperator(PQLOperator):
    """PQLOperator for integer values."""

    def __init__(self, integer: int):
        """Initialises IntegerPQLOperator with given value."""
        self._integer = integer

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return str(self._integer)


class FloatPQLOperator(PQLOperator):
    """PQLOperator for float values."""

    def __init__(self, float_: float):
        """Initialises FloatPQLOperator with given value."""
        self._float = float_

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return str(self._float)


class DatetimePQLOperator(PQLOperator):
    """PQLOperator for datetime values."""

    def __init__(self, datetime_: datetime):
        """Initialises DatetimePQLOperator with given value."""
        self._datetime = datetime_

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return self._datetime.strftime("{d '%Y-%m-%d %H:%M:%S'}")


class ScalarPQLOperatorFactory:
    """Factory to create scalar PQL operator from scalar values."""

    @staticmethod
    def get_operator(operator: ScalarValue) -> PQLOperator:
        """Converts scalar values to PQLOperator."""
        if isinstance(operator, str):
            return StringPQLOperator(operator)
        if isinstance(operator, int):
            return IntegerPQLOperator(operator)
        if isinstance(operator, float):
            return FloatPQLOperator(operator)
        if isinstance(operator, datetime):
            return DatetimePQLOperator(operator)
        raise TypeError(f"Operand type {type(operator)} not supported for ScalarPQLOperatorFactory")
