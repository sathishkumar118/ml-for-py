from typing import Optional, Union

from saolapy.operator import PQLOperator
from saolapy.operator.arithmetic import AddOperator, SubtractOperator
from saolapy.operator.base import BinaryPQLOperator, UnaryPQLOperator
from saolapy.operator.boolean import GreaterEqualsOperator, LowerThanOperator, OrOperator
from saolapy.operator.scalar import IntegerPQLOperator, ScalarPQLOperatorFactory, StringPQLOperator
from saolapy.types import ScalarValue


class ConcatenateOperator(BinaryPQLOperator):
    """Concatenate operator that concatenates the left operand with the right operand.

    Applies [CONCAT operator](https://docs.celonis.com/en/concat.html) to column.
    """

    @property
    def query_string(self) -> str:
        """Returns query string."""
        return f"( {self._lhs_operand.query_string} || {self._rhs_operand.query_string} )"


class LengthOperator(UnaryPQLOperator):
    """Length operator that returns len of string.

    Applies [LEN operator](https://docs.celonis.com/en/len.html) to column.
    """

    @property
    def query_string(self) -> str:
        return f"LEN( {self._operand.query_string} )"


class LowerOperator(UnaryPQLOperator):
    """Lower operator that returns string in lower case.

    Applies [LOWER operator](https://docs.celonis.com/en/lower.html) to column.
    """

    @property
    def query_string(self) -> str:
        return f"LOWER( {self._operand.query_string} )"


class UpperOperator(UnaryPQLOperator):
    """Upper operator that returns string in upper case.

    Applies [UPPER operator](https://docs.celonis.com/en/upper.html) to column.
    """

    @property
    def query_string(self) -> str:
        return f"UPPER( {self._operand.query_string} )"


class LStripOperator(UnaryPQLOperator):
    """LStrip operator that returns the string with leading whitespace removed.

    Applies [LTRIM operator](https://docs.celonis.com/en/ltrim.html) to column.
    """

    @property
    def query_string(self) -> str:
        return f"LTRIM( {self._operand.query_string} )"


class RStripOperator(UnaryPQLOperator):
    """RStrip operator that returns the string with trailing whitespace removed.

    Applies [RTRIM operator](https://docs.celonis.com/en/rtrim.html) to column.
    """

    @property
    def query_string(self) -> str:
        return f"RTRIM( {self._operand.query_string} )"


class StripOperator(UnaryPQLOperator):
    """Strip operator that returns the string with leading and trailing whitespace removed.

    Applies [RTRIM operator](https://docs.celonis.com/en/rtrim.html) and
    [LTRIM operator](https://docs.celonis.com/en/ltrim.html) to column.
    """

    @property
    def query_string(self) -> str:
        return f"LTRIM( RTRIM( {self._operand.query_string} ) )"


class ReplaceOperator(UnaryPQLOperator):
    """Replace operator that replaces the given string with the given value.

    Applies [REPLACE operator](https://docs.celonis.com/en/replace.html) to column.
    """

    def __init__(
        self,
        operand: Union["ScalarValue", PQLOperator],
        to_replace: Union["ScalarValue", PQLOperator],
        value: Union["ScalarValue", PQLOperator],
    ):
        """Initializes ReplaceOperator.

        Args:
            operand: Operand on which replace method is applied.
            to_replace: String to replace.
            value: Value to use as replacement.
        """
        super().__init__(operand)

        self._to_replace: PQLOperator = (
            to_replace if isinstance(to_replace, PQLOperator) else ScalarPQLOperatorFactory.get_operator(to_replace)
        )

        self._value: PQLOperator = (
            value if isinstance(value, PQLOperator) else ScalarPQLOperatorFactory.get_operator(value)
        )

    @property
    def query_string(self) -> str:
        return (
            "REPLACE( "
            f"{self._operand.query_string}, {self._to_replace.query_string}, {self._value.query_string}"
            " )"
        )


class SubstringOperator(UnaryPQLOperator):
    """Substring operator that returns substring.

    Applies [SUBSTRING operator](https://docs.celonis.com/en/substring.html) to column.
    """

    def __init__(
        self, operand: Union["ScalarValue", PQLOperator], start: Optional[int] = None, stop: Optional[int] = None
    ) -> None:
        """Initializes SubstringOperator.

        Args:
            operand: Operand of which substring is taken.
            start: Start of substring.
            stop: End of substring.
        """
        super().__init__(operand)
        self._start = start
        self._stop = stop

    @property
    def query_string(self) -> str:
        length_operator = LengthOperator(self._operand)

        if self._start is None:
            start_operator: PQLOperator = IntegerPQLOperator(0)
        elif self._start < 0:
            start_operator = AddOperator(length_operator, IntegerPQLOperator(self._start))
        else:
            start_operator = IntegerPQLOperator(self._start)

        if self._stop is None:
            stop_operator: PQLOperator = length_operator
        elif self._stop < 0:
            stop_operator = AddOperator(length_operator, self._stop)
        else:
            stop_operator = IntegerPQLOperator(self._stop)

        size_operator = SubtractOperator(stop_operator, start_operator)
        return (
            "SUBSTRING( "
            f"{self._operand.query_string}, "
            f"{start_operator.query_string}, "
            f"CASE WHEN {size_operator.query_string} > 0 THEN {size_operator.query_string} ELSE 0 END "
            ")"
        )


class StringIndexOperator(UnaryPQLOperator):
    """String index operator that returns character at given index.

    Applies [SUBSTRING operator](https://docs.celonis.com/en/substring.html) to column.
    """

    def __init__(self, operand: Union["ScalarValue", PQLOperator], index: int) -> None:
        """Initializes StringIndexOperator.

        Args:
            operand: Operand of which substring is taken.
            index: Index of character to extract.
        """
        super().__init__(operand)
        self._index: int = index

    @property
    def query_string(self) -> str:
        length_operator = LengthOperator(self._operand)

        if self._index >= 0:
            index: PQLOperator = IntegerPQLOperator(self._index)
        else:
            index = AddOperator(length_operator, self._index)

        null_condition_operator = OrOperator(GreaterEqualsOperator(index, length_operator), LowerThanOperator(index, 0))
        return (
            "( CASE "
            f"WHEN {null_condition_operator.query_string} THEN NULL "
            f"ELSE SUBSTRING( {self._operand.query_string}, {index}, 1 ) "
            "END )"
        )


class StartsWithOperator(UnaryPQLOperator):
    """StartsWith operator that returns whether string starts with given pattern.

    Applies [LIKE operator](https://docs.celonis.com/en/like.html) to column.
    """

    is_boolean = True

    def __init__(self, operand: Union["ScalarValue", PQLOperator], pattern: str) -> None:
        """Initializes StartsWith.

        Args:
            operand: Operand of which substring is taken.
            pattern: Pattern for which is searched.
        """
        super().__init__(operand)
        self._pattern = StringPQLOperator(f"{pattern}%")

    @property
    def query_string(self) -> str:
        return f"( {self._operand.query_string} LIKE {self._pattern.query_string} )"


class EndsWithOperator(UnaryPQLOperator):
    """EndsWith operator that returns whether string ends with given pattern.

    Applies [LIKE operator](https://docs.celonis.com/en/like.html) to column.
    """

    is_boolean = True

    def __init__(self, operand: Union["ScalarValue", PQLOperator], pattern: str) -> None:
        """Initializes EndsWithOperator.

        Args:
            operand: Operand of which substring is taken.
            pattern: Pattern for which is searched.
        """
        super().__init__(operand)
        self._pattern = StringPQLOperator(f"%{pattern}")

    @property
    def query_string(self) -> str:
        return f"( {self._operand.query_string} LIKE {self._pattern.query_string} )"


class ContainsOperator(UnaryPQLOperator):
    """Contains operator that returns whether string contains given pattern.

    Applies [LIKE operator](https://docs.celonis.com/en/like.html) to column.
    """

    is_boolean = True

    def __init__(self, operand: Union["ScalarValue", PQLOperator], pattern: str) -> None:
        """Initializes ContainsOperator.

        Args:
            operand: Operand of which substring is taken.
            pattern: Pattern for which is searched.
        """
        super().__init__(operand)
        self._pattern = StringPQLOperator(f"%{pattern}%")

    @property
    def query_string(self) -> str:
        return f"( {self._operand.query_string} LIKE {self._pattern.query_string} )"
