"""Module for pandas functionality."""
from typing import Any, Optional, OrderedDict


class ImmutableObject:
    """Base class for immutable objects."""

    def __setattr__(self, key: str, value: Any) -> None:
        raise AttributeError(f"{self.__class__.__name__} objects are immutable!")

    def _set_attr(self, key: str, value: Any) -> None:
        object.__setattr__(self, key, value)

    @staticmethod
    def object_str(class_name: str, properties: OrderedDict[str, Any]) -> str:
        """Returns string representation of object with given class name and properties.

        Args:
            class_name: Name of object class.
            properties: Properties to include.

        Returns:
            String representation.
        """
        properties_string = ", ".join(f"{key}={value!r}" for key, value in properties.items())
        return f"{class_name}({properties_string})"

    @staticmethod
    def shorten_string(string: str, max_length: Optional[int] = None) -> str:
        """Shortens string to have maximum of `max_length` characters."""
        if max_length is None:
            return string
        return string if len(string) <= max_length else string[: max(0, max_length - 3)] + "..."
