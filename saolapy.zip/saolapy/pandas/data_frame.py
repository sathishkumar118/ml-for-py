import typing
from collections import OrderedDict
from collections.abc import Iterable
from typing import Any, List, MutableMapping, Optional, Sequence, Tuple, Type, Union, overload

import numpy as np
import pandas as pd

from saolapy.operator import PQLOperator
from saolapy.operator.aggregation import (
    AvgOperator,
    CountDistinctNullOperator,
    CountDistinctOperator,
    CountNullOperator,
    CountOperator,
    MaxOperator,
    MedianOperator,
    MinOperator,
    ModeOperator,
    ProductOperator,
    QuantileOperator,
    StandardDeviationOperator,
    SumOperator,
    VarianceOperator,
)
from saolapy.operator.arithmetic import (
    AbsOperator,
    AddOperator,
    DivideOperator,
    FloorDivisionOperator,
    ModuloOperator,
    MultiplyOperator,
    PowerOperator,
    RoundOperator,
    SubtractOperator,
)
from saolapy.operator.base import BinaryPQLOperator, UnaryPQLOperator
from saolapy.operator.boolean import (
    AndOperator,
    EqualsOperator,
    GreaterEqualsOperator,
    GreaterThanOperator,
    IsInOperator,
    IsNullOperator,
    LowerEqualsOperator,
    LowerThanOperator,
    NotEqualsOperator,
    OrOperator,
)
from saolapy.operator.data_type import ToDateOperator, ToFloatOperator, ToIntOperator, ToStringOperator
from saolapy.pandas import ImmutableObject
from saolapy.pandas.filters import Filters
from saolapy.pandas.index import BaseIndex, RangeIndex
from saolapy.pandas.series import Series
from saolapy.pandas.util import verify_compatibility
from saolapy.pql.base import PQL, OrderByColumn, PQLColumn, PQLFilter
from saolapy.pql.formatter import OrderByColumnFormatter
from saolapy.saola_connector import SaolaConnector
from saolapy.types import (
    FilterLike,
    FiltersLike,
    NumericValue,
    ScalarValue,
    SeriesLike,
    convert_numpy_to_python,
    is_scalar_value,
)

if typing.TYPE_CHECKING:
    from saolapy.pandas.group_by_aggregation import GroupByAggregationMethods


class DataFrame(ImmutableObject):
    """Two dimensional PQL DataFrame."""

    _series_class: Type[Series] = Series

    _data: typing.OrderedDict[str, Series]
    _index: BaseIndex
    _filters: Filters
    _order_by_columns: List[OrderByColumn]
    _saola_connector: Optional[SaolaConnector]

    def __init__(
        self,
        data: MutableMapping[str, SeriesLike],
        index: Optional[BaseIndex] = None,
        filters: Optional[FiltersLike] = None,
        order_by_columns: Optional[List[OrderByColumn]] = None,
        saola_connector: Optional[SaolaConnector] = None,
    ):
        """Initializes data frame.

        Args:
            data: Dictionary with data to be used for data frames. Keys are column keys and values can be either Series,
                PQL query string, PQLColumn, or PQLOperator.
            index: Index to be used. Default is RangeIndex.
            filters: Filters to be used. Default is none.
            order_by_columns: OrderByColumns to be used to sort data frame. Default is none.
            saola_connector: Saola connector used to export data.
        """
        self._set_attr("_data", OrderedDict())
        self._set_attr("_index", index or RangeIndex())
        self._set_attr(
            "_filters", filters if isinstance(filters, Filters) else Filters(filters, saola_connector=saola_connector)
        )
        self._set_attr("_order_by_columns", order_by_columns or [])
        self._set_attr("_saola_connector", saola_connector)

        # Set columns
        for name, series in data.items():
            self[name] = series

    ############################################################
    # Attributes
    ############################################################
    @property
    def index(self) -> BaseIndex:
        """Returns index of data frame."""
        return self._index

    @property
    def filters(self) -> Filters:
        """Returns filters of data frame."""
        return self._filters

    @property
    def order_by_columns(self) -> List[OrderByColumn]:
        """Returns order by columns of data frame."""
        return self._order_by_columns

    @property
    def saola_connector(self) -> SaolaConnector:
        """Returns saola connector of data frame."""
        if not self._saola_connector:
            raise ValueError(
                "Can't export data as there is no `saola_connector` or `data_model` set. "
                "For more information see our quickstart tutorial:\n\n"
                "https://celonis.github.io/pycelonis/2.4.1/tutorials/executed/05_saolapy/03_dataframe/#1-connect-to-your-data-model"  # pylint: disable=line-too-long
            )
        return self._saola_connector

    ############################################################
    # Static Methods
    ############################################################
    @classmethod
    def from_pql(cls, query: PQL, **kwargs: Any) -> "DataFrame":
        """Creates data frame from PQL query.

        Args:
            query: PQL query to create data frame from.

        Returns:
            DataFrame created from PQL query.
        """
        return cls(
            data={column.name: column.query for column in query.columns},
            filters=query.filters,
            order_by_columns=query.order_by_columns,
            **kwargs,
        )

    ############################################################
    # Query Properties
    ############################################################
    @property
    def query(self) -> PQL:
        """Returns PQL query of data frame."""
        return PQL() + self.index.query_columns + self.query_columns + self.query_filters + self.query_order_by_columns

    @property
    def query_columns(self) -> Sequence[PQLColumn]:
        """Returns list of PQL columns of data frame."""
        return [PQLColumn(query=series.query_column.query, name=name) for name, series in self._data.items()]

    @property
    def query_filters(self) -> List[PQLFilter]:
        """Returns filters of data frame."""
        return self._filters.pql_filters

    @property
    def query_order_by_columns(self) -> List[OrderByColumn]:
        """Returns order by columns of series."""
        return self.order_by_columns

    @property
    def columns(self) -> Sequence[str]:
        """Returns column names of data frame."""
        return list(self._data.keys())

    ############################################################
    # Accessor Functions
    ############################################################
    @overload
    def __getitem__(self, key: str) -> Series:
        ...

    @overload
    def __getitem__(self, key: Union[PQLOperator, Series, "DataFrame", List[str]]) -> "DataFrame":
        ...

    def __getitem__(self, key: Union[str, PQLOperator, Series, "DataFrame", List[str]]) -> Union["DataFrame", Series]:
        if isinstance(key, str):  # Return Series with given key
            return self._data[key]

        if isinstance(key, list):  # Return DataFrame containing Series' with given keys
            return self.copy(data=OrderedDict([(col, self[col]) for col in key]))

        if isinstance(key, PQLOperator):  # Apply PQLOperator as Filter
            return self.copy(filters=self.filters.add(key))

        if isinstance(key, Series):  # Apply Series as Filter
            verify_compatibility(self.index, key.index, self.filters, key.filters)
            return self.copy(filters=self.filters.add(key.data))

        if isinstance(key, DataFrame):  # Apply all Series of DataFrame as Filters
            verify_compatibility(self.index, key.index, self.filters, key.filters)

            filters = self.filters
            for column in key.columns:
                filters = filters.add(key[column].data)
            return self.copy(filters=filters)

        raise KeyError(f"Key of type {type(key)} needs to be of type str, PQLOperator, Series, or DataFrame.")

    def __setitem__(self, key: Union[str, List[str]], value: Union["DataFrame", SeriesLike, List[SeriesLike]]) -> None:
        if isinstance(key, str):  # Set Series with given key to value
            series = self._convert_to_series(name=key, series=value)
            verify_compatibility(self._index, series.index, self._filters, series.filters)
            self._data[key] = series

        elif isinstance(key, list):  # Set Series' with given keys to corresponding Series from DataFrame value
            if isinstance(value, DataFrame):
                value = [value[column] for column in value.columns]

            if isinstance(value, Iterable) and not isinstance(value, str):
                if len(key) != len(value):  # type: ignore
                    raise ValueError(
                        f"Length of keys does not match number of values: {len(key)} != {len(value)}"  # type: ignore
                    )

                for column_name, column_value in zip(key, value):
                    self[column_name] = column_value

            else:
                raise ValueError(f"Value needs to be of type DataFrame or Iterable and not {type(value)}.")

        else:
            raise KeyError(f"Key needs to be of type string or list of strings and not {type(key)}.")

    def __getattr__(self, name: str) -> Any:
        """If name is contained in columns returns Series. Otherwise, returns attribute.

        Args:
            name: Column or attribute to access.

        Returns:
            Column or attribute.
        """
        if name in self.columns:
            return self[name]
        return object.__getattribute__(self, name)

    def __setattr__(self, name: str, value: Any) -> None:
        """Sets attribute if it is column and does not exist as property or function on data frame.

        Args:
            name: Name of attribute to set.
            value: Value to set attribute to.
        """
        try:
            object.__getattribute__(self, name)
            super().__setattr__(name, value)
        except AttributeError:
            if name in self.columns:
                self[name] = value
            else:
                super().__setattr__(name, value)

    ############################################################
    # String Representation
    ############################################################
    def __repr__(self) -> str:
        """Returns string representation of data frame."""
        properties: typing.OrderedDict[str, Any] = OrderedDict()
        properties["data"] = self._data
        properties["index"] = self.index
        properties["filters"] = self.filters
        properties["order_by_columns"] = self.order_by_columns
        properties["saola_connector"] = self._saola_connector

        return ImmutableObject.object_str(self.__class__.__name__, properties)

    def __str__(self) -> "str":  # type: ignore
        """Returns string representation of object."""
        max_length = 50

        properties: typing.OrderedDict[str, Any] = OrderedDict()
        properties["data"] = {
            name: ImmutableObject.shorten_string(series.data.query_string, max_length)
            for name, series in self._data.items()
        }
        properties["index"] = self.index
        properties["filters"] = [
            ImmutableObject.shorten_string(filter_.query, max_length) for filter_ in self.filters.pql_filters
        ]
        properties["order_by_columns"] = [
            ImmutableObject.shorten_string(OrderByColumnFormatter().format(col), max_length)
            for col in self.order_by_columns
        ]

        return ImmutableObject.object_str(self.__class__.__name__, properties)

    def _repr_pretty_(self, p: Any, cycle: bool) -> None:
        p.text(str(self) if not cycle else "...")

    ############################################################
    # Export Functions
    ############################################################
    def head(self, n: int = 5) -> pd.DataFrame:
        """Returns the first n rows based on position as pandas DataFrame.

        Args:
            n: Number of rows to return.

        Returns:
            First n rows as pandas DataFrame.
        """
        return self.to_pandas(limit=n)

    def to_pandas(
        self, distinct: Optional[bool] = None, limit: Optional[int] = None, offset: Optional[int] = None
    ) -> pd.DataFrame:
        """Exports data using saola_connector."""
        if self.ncolumns == 0:
            return pd.DataFrame()

        exported_data = self.saola_connector.export_data(self.query, distinct=distinct, limit=limit, offset=offset)
        exported_data = exported_data.set_index(self.index.query_column_names, drop=True)
        return exported_data

    ############################################################
    # Dimensionality Functions
    ############################################################
    @property
    def ndim(self) -> int:
        """Returns an int representing the number of axes."""
        return 2

    @property
    def nrows(self) -> int:
        """Returns an int representing the number of rows of this data frame."""
        nrows_series = self.apply_aggregation_operator(CountNullOperator).fillna(0)
        return nrows_series.iloc[0] if nrows_series.shape[0] > 0 else 0

    @property
    def ncolumns(self) -> int:
        """Returns an int representing the number of columns of this data frame."""
        return len(self.columns)

    @property
    def size(self) -> int:
        """Returns an int representing the number of elements in this data frame."""
        return self.nrows * self.ncolumns

    @property
    def shape(self) -> Tuple[int, int]:
        """Returns a tuple representing the shape of this data frame."""
        return self.nrows, self.ncolumns

    @property
    def empty(self) -> bool:
        """Returns whether data frame is empty."""
        return self.size == 0

    ############################################################
    # Arithmetic Functions
    ############################################################
    def add(self, other: Union["DataFrame", Series, NumericValue]) -> "DataFrame":
        """Return addition of data frame and other.

        Applies [ADD operator](https://docs.celonis.com/en/add.html) to column.

        Args:
            other: DataFrame, Series or numeric scalar to be added.

        Returns:
            The result of the operation.
        """
        return self.apply_binary_operator(other, AddOperator)

    def __add__(self, other: Union["DataFrame", Series, NumericValue]) -> "DataFrame":
        return self.apply_binary_operator_dunder(other, AddOperator)

    def __radd__(self, other: Union["DataFrame", Series, NumericValue]) -> "DataFrame":
        return self.apply_binary_operator_dunder(other, AddOperator, reverse=True)

    def sub(self, other: Union["DataFrame", Series, NumericValue]) -> "DataFrame":
        """Return subtraction of data frame and other.

        Applies [SUB operator](https://docs.celonis.com/en/sub.html) to column.

        Args:
            other: DataFrame, Series or numeric scalar to be subtracted.

        Returns:
            The result of the operation.
        """
        return self.apply_binary_operator(other, SubtractOperator)

    def __sub__(self, other: Union["DataFrame", Series, NumericValue]) -> "DataFrame":
        return self.apply_binary_operator_dunder(other, SubtractOperator)

    def __rsub__(self, other: Union["DataFrame", Series, NumericValue]) -> "DataFrame":
        return self.apply_binary_operator_dunder(other, SubtractOperator, reverse=True)

    def mul(self, other: Union["DataFrame", Series, NumericValue]) -> "DataFrame":
        """Return multiplication of data frame and other.

        Applies [MULT operator](https://docs.celonis.com/en/mult.html) to column.

        Args:
            other: DataFrame, Series or numeric scalar to be multiplied.

        Returns:
            The result of the operation.
        """
        return self.apply_binary_operator(other, MultiplyOperator)

    def __mul__(self, other: Union["DataFrame", Series, NumericValue]) -> "DataFrame":
        return self.apply_binary_operator_dunder(other, MultiplyOperator)

    def __rmul__(self, other: Union["DataFrame", Series, NumericValue]) -> "DataFrame":
        return self.apply_binary_operator_dunder(other, MultiplyOperator, reverse=True)

    def div(self, other: Union["DataFrame", Series, NumericValue]) -> "DataFrame":
        """Return division of data frame and other.

        Applies [DIV operator](https://docs.celonis.com/en/div.html) to column.

        Args:
            other: DataFrame, Series or numeric scalar to be divided.

        Returns:
            The result of the operation.
        """
        return self.apply_binary_operator(other, DivideOperator)

    def __truediv__(self, other: Union["DataFrame", Series, NumericValue]) -> "DataFrame":
        return self.apply_binary_operator_dunder(other, DivideOperator)

    def __rtruediv__(self, other: Union["DataFrame", Series, NumericValue]) -> "DataFrame":
        return self.apply_binary_operator_dunder(other, DivideOperator, reverse=True)

    def floordiv(self, other: Union["DataFrame", Series, NumericValue]) -> "DataFrame":
        """Return floor division of data frame and other.

        Applies [FLOOR operator](https://docs.celonis.com/en/floor.html) and
        [DIV operator](https://docs.celonis.com/en/div.html) to column.

        Args:
            other: DataFrame, Series or numeric scalar to be floor divided.

        Returns:
            The result of the operation.
        """
        return self.apply_binary_operator(other, FloorDivisionOperator)

    def __floordiv__(self, other: Union["DataFrame", Series, NumericValue]) -> "DataFrame":
        return self.apply_binary_operator_dunder(other, FloorDivisionOperator)

    def __rfloordiv__(self, other: Union["DataFrame", Series, NumericValue]) -> "DataFrame":
        return self.apply_binary_operator_dunder(other, FloorDivisionOperator, reverse=True)

    def mod(self, other: Union["DataFrame", Series, NumericValue]) -> "DataFrame":
        """Return modulo of data frame and other.

        Applies [MODULO operator](https://docs.celonis.com/en/modulo.html) to column.

        Args:
            other: DataFrame, Series or numeric scalar to be modulo'd.

        Returns:
            The result of the operation.
        """
        return self.apply_binary_operator(other, ModuloOperator)

    def __mod__(self, other: Union["DataFrame", Series, NumericValue]) -> "DataFrame":
        return self.apply_binary_operator_dunder(other, ModuloOperator)

    def __rmod__(self, other: Union["DataFrame", Series, NumericValue]) -> "DataFrame":
        return self.apply_binary_operator_dunder(other, ModuloOperator, reverse=True)

    def pow(self, other: Union["DataFrame", Series, NumericValue]) -> "DataFrame":
        """Return the data frame raised to the power of other.

        Applies [POWER operator](https://docs.celonis.com/en/power.html) to column.

        Args:
            other: DataFrame, Series or numeric scalar to be the exponent.

        Returns:
            The result of the operation.
        """
        return self.apply_binary_operator(other, PowerOperator)

    def __pow__(self, other: Union["DataFrame", Series, NumericValue]) -> "DataFrame":
        return self.apply_binary_operator_dunder(other, PowerOperator)

    def __rpow__(self, other: Union["DataFrame", Series, NumericValue]) -> "DataFrame":
        return self.apply_binary_operator_dunder(other, PowerOperator, reverse=True)

    def abs(self) -> "DataFrame":
        """Return the DataFrame with the absolute value of its elements.

        Applies [ABS operator](https://docs.celonis.com/en/abs.html) to column.
        """
        return self.apply_unary_operator(AbsOperator)

    def round(self, decimals: int = 0) -> "DataFrame":
        """Round dataframe to given number of decimals.

        Applies [ROUND operator](https://docs.celonis.com/en/round.html) to column.
        """
        return self.apply_unary_operator(RoundOperator, decimals=decimals)

    ############################################################
    # Boolean Functions
    ############################################################
    def __contains__(self, item: Any) -> bool:
        """Returns whether item is in column names.

        Args:
            item: Name of column to check for.

        Returns:
            Boolean whether item is in column names.
        """
        return item in self.columns

    def lt(self, other: Union["DataFrame", "Series", pd.Series, ScalarValue]) -> "DataFrame":
        """Return a DataFrame of booleans indicating whether each element is less than the other.

        Applies [LOWER_THAN operator](https://docs.celonis.com/en/comparison-operators.html) to column.

        Args:
            other: DataFrame, Series or scalar to be compared.

        Returns:
            The result of the operation.
        """
        return self.apply_binary_operator(other, LowerThanOperator)

    def __lt__(self, other: Union["DataFrame", "Series", pd.Series, ScalarValue]) -> "DataFrame":
        """Return a DataFrame of booleans indicating whether each element is less than the other.

        Args:
            other: DataFrame, Series or scalar to be compared.

        Returns:
            The result of the operation.
        """
        return self.apply_binary_operator_dunder(other, LowerThanOperator)

    def le(self, other: Union["DataFrame", "Series", pd.Series, ScalarValue]) -> "DataFrame":
        """Return a DataFrame of booleans indicating whether each element is less than or equal to the other.

        Applies [LOWER_EQUALS operator](https://docs.celonis.com/en/comparison-operators.html) to column.

        Args:
            other: DataFrame, Series or scalar to be compared.

        Returns:
            The result of the operation.
        """
        return self.apply_binary_operator(other, LowerEqualsOperator)

    def __le__(self, other: Union["DataFrame", "Series", pd.Series, ScalarValue]) -> "DataFrame":
        return self.apply_binary_operator_dunder(other, LowerEqualsOperator)

    def eq(self, other: Union["DataFrame", "Series", pd.Series, ScalarValue]) -> "DataFrame":
        """Return a DataFrame of booleans indicating whether each element is equal to the other.

        Applies [EQUALS operator](https://docs.celonis.com/en/comparison-operators.html) to column.

        Args:
            other: DataFrame, Series or scalar to be compared.

        Returns:
            The result of the operation.
        """
        return self.apply_binary_operator(other, EqualsOperator)

    def __eq__(self, other: Any) -> "DataFrame":  # type: ignore
        if isinstance(other, (DataFrame, Series)) or is_scalar_value(other):
            return self.apply_binary_operator_dunder(other, EqualsOperator)
        raise TypeError(f"Data type {type(other)} not supported.")

    def ne(self, other: Union["DataFrame", "Series", pd.Series, ScalarValue]) -> "DataFrame":
        """Return a DataFrame of booleans indicating whether each element is not equal to the other.

        Applies [NOT_EQUALS operator](https://docs.celonis.com/en/comparison-operators.html) to column.

        Args:
            other: DataFrame, Series or scalar to be compared.

        Returns:
            The result of the operation.
        """
        return self.apply_binary_operator(other, NotEqualsOperator)

    def __ne__(self, other: Any) -> "DataFrame":  # type: ignore
        if isinstance(other, (DataFrame, Series)) or is_scalar_value(other):
            return self.apply_binary_operator_dunder(other, NotEqualsOperator)
        raise TypeError(f"Data type {type(other)} not supported.")

    def ge(self, other: Union["DataFrame", "Series", pd.Series, ScalarValue]) -> "DataFrame":
        """Return a DataFrame of booleans indicating whether each element is greater than or equal to the other.

        Applies [GREATER_EQUALS operator](https://docs.celonis.com/en/comparison-operators.html) to column.

        Args:
            other: DataFrame, Series or scalar to be compared.

        Returns:
            The result of the operation.
        """
        return self.apply_binary_operator(other, GreaterEqualsOperator)

    def __ge__(self, other: Union["DataFrame", "Series", pd.Series, ScalarValue]) -> "DataFrame":
        return self.apply_binary_operator_dunder(other, GreaterEqualsOperator)

    def gt(self, other: Union["DataFrame", "Series", pd.Series, ScalarValue]) -> "DataFrame":
        """Return a DataFrame of booleans indicating whether each element is greater than the other.

        Applies [GREATER_THAN operator](https://docs.celonis.com/en/comparison-operators.html) to column.

        Args:
            other: DataFrame, Series or scalar to be compared.

        Returns:
            The result of the operation.
        """
        return self.apply_binary_operator(other, GreaterThanOperator)

    def __gt__(self, other: Union["DataFrame", "Series", pd.Series, ScalarValue]) -> "DataFrame":
        return self.apply_binary_operator_dunder(other, GreaterThanOperator)

    def __and__(self, other: Union["DataFrame", "Series", pd.Series]) -> "DataFrame":
        """Return a DataFrame of booleans indicating the result of the logical AND operation.

        Applies [AND operator](https://docs.celonis.com/en/and.html) to column.

        Args:
            other: DataFrame or Series to be combined.

        Returns:
            The result of the operation.
        """
        return self.apply_binary_operator(other, AndOperator)

    def __or__(self, other: Union["DataFrame", "Series", pd.Series]) -> "DataFrame":
        """Return a DataFrame of booleans indicating the result of the logical OR operation.

        Applies [OR operator](https://docs.celonis.com/en/or.html) to column.

        Args:
            other: DataFrame or Series to be combined.

        Returns:
            The result of the operation.
        """
        return self.apply_binary_operator_dunder(other, OrOperator)

    def __invert__(self) -> "DataFrame":
        """Return a DataFrame of booleans indicating the result of the logical NOT operation.

        Returns:
            The result of the operation.
        """
        data_frame = self.copy()
        for column in data_frame.columns:
            data_frame[column] = ~data_frame[column]
        return data_frame

    def isnull(self) -> "DataFrame":
        """Return a boolean same-sized DataFrame indicating if the values are null.

        Applies [IS NULL operator](https://docs.celonis.com/en/is-null.html) to column.

        Returns:
            A DataFrame of masked bool values for each element that indicates whether an element is a null value.
        """
        return self.apply_unary_operator(IsNullOperator)

    def isin(self, values: List[Union["Series", ScalarValue]]) -> "DataFrame":
        """Returns whether elements of data frame are in values.

        Applies [IN operator](https://docs.celonis.com/en/in.html) to column.

        Args:
            values: List of values to test.

        Returns:
            The result of the operation.
        """
        converted_values = [value.data if isinstance(value, Series) else value for value in values]
        return self.apply_unary_operator(IsInOperator, values=converted_values)

    def dropna(self) -> "DataFrame":
        """Return DataFrame with filter for null values. Rows are removed if any column is null.

        Returns:
            A DataFrame with null values filtered out.
        """
        return self[~self.isnull()]

    ############################################################
    # Aggregation Functions
    ############################################################
    def mean(self) -> pd.Series:
        """Return the mean of each column.

        Applies [AVG operator](https://docs.celonis.com/en/avg.html) to column.

        Returns:
            Mean of column values.
        """
        return self.apply_aggregation_operator(AvgOperator)

    def median(self) -> pd.Series:
        """Return the median of each column.

        Applies [MEDIAN operator](https://docs.celonis.com/en/median.html) to column.

        Returns:
            Median of column values.
        """
        return self.apply_aggregation_operator(MedianOperator)

    def quantile(self, q: float = 0.5) -> pd.Series:
        """Return the quantile of each column.

        Applies [QUANTILE operator](https://docs.celonis.com/en/quantile.html) to column.

        Args:
            q: Quantile to compute. 0 <= q <= 1.

        Returns:
            Quantile of series values.
        """
        return self.apply_aggregation_operator(QuantileOperator, quantile=q)

    def mode(self) -> pd.DataFrame:
        """Return the mode of each column.

        Applies [MODE operator](https://docs.celonis.com/en/mode.html) to column.

        Returns:
            Mode of column values.
        """
        # Uses unary operator since return value is data frame
        return self.apply_unary_operator(ModeOperator).to_pandas()

    def max(self) -> pd.Series:
        """Return the max of each column.

        Applies [MAX operator](https://docs.celonis.com/en/max.html) to column.

        Returns:
            Max of column values.
        """
        return self.apply_aggregation_operator(MaxOperator)

    def min(self) -> pd.Series:
        """Return the min of each column.

        Applies [MIN operator](https://docs.celonis.com/en/min.html) to column.

        Returns:
            Min of column values.
        """
        return self.apply_aggregation_operator(MinOperator)

    def sum(self) -> pd.Series:
        """Return the sum of each column.

        Applies [SUM operator](https://docs.celonis.com/en/sum.html) to column.

        Returns:
            Sum of column values.
        """
        return self.apply_aggregation_operator(SumOperator)

    def product(self) -> pd.Series:
        """Return the product of each column. Null values are skipped.

        Applies [PRODUCT operator](https://docs.celonis.com/en/product.html) to column.
        In case of an overflow the result will be null.

        Returns:
            Product of column values.
        """
        return self.apply_aggregation_operator(ProductOperator)

    def count(self) -> pd.Series:
        """Return the number of non-null values per column of data frame.

        Applies [COUNT operator](https://docs.celonis.com/en/count.html) to column.

        Returns:
            Number of non-null values per column.
        """
        return self.apply_aggregation_operator(CountOperator)

    def groupby(self, by: Union[str, List[str]]) -> "GroupByAggregationMethods":
        """Return the group by aggregation methods containing all aggregation methods.

        Args:
            by: Used to determine the groups the aggregation method is applied on.

        Returns:
            GroupByAggregationMethods object
        """
        from saolapy.pandas.group_by_aggregation import GroupByAggregationMethods

        return GroupByAggregationMethods(self, group_by_columns=[by] if isinstance(by, str) else by)

    def var(self) -> pd.Series:
        """Return the variance of each column using the n-1 method. Null values are ignored.

        Applies [VAR operator](https://docs.celonis.com/en/var.html) to column.

        Returns:
            Variance of column values.
        """
        return self.apply_aggregation_operator(VarianceOperator)

    def std(self) -> pd.Series:
        """Return the standard deviation of each column using the n-1 method. Null values are ignored.

        Applies [STDEV operator](https://docs.celonis.com/en/stdev.html) to column.

        Returns:
            Standard deviation of column values.
        """
        return self.apply_aggregation_operator(StandardDeviationOperator)

    ############################################################
    # Type Conversion Functions
    ############################################################
    def to_int(self) -> "DataFrame":
        """Converts columns of given data frame to int.

        Applies [TO_INT operator](https://docs.celonis.com/en/to_int.html) to column.
        """
        return self.apply_unary_operator(ToIntOperator)

    def to_float(self) -> "DataFrame":
        """Converts columns of given data frame to float.

        Applies [TO_FLOAT operator](https://docs.celonis.com/en/to_float.html) to column.
        """
        return self.apply_unary_operator(ToFloatOperator)

    def to_string(self, format_: Optional["str"] = None) -> "DataFrame":  # type: ignore
        """Converts columns of given data frame to string.

        Applies [TO_STRING operator](https://docs.celonis.com/en/to_string.html) to column.

        Args:
            format_: Optional, defines how dates are converted to string.

        Returns:
            DataFrame converted to string.
        """
        return self.apply_unary_operator(ToStringOperator, format_=format_)

    def to_date(self, format_: "str") -> "DataFrame":  # type: ignore
        """Converts columns of given data frame to date.

        Applies [TO_DATE operator](https://docs.celonis.com/en/to_date.html) to column.

        Args:
            format_: Defines how strings are converted to date.

        Returns:
            DataFrame converted to date.
        """
        return self.apply_unary_operator(ToDateOperator, format_=format_)

    def astype(self, type_: Type[Union["str", int, float]], **kwargs: Any) -> "DataFrame":  # type: ignore
        """Converts columns of given data frame to type.

        Args:
            type_: Type to convert to. Supported types are str, int, float.
            **kwargs: Passed to conversion function.

        Returns:
            Converted DataFrame.
        """
        if type_ == int:
            return self.to_int()
        if type_ == float:
            return self.to_float()
        if type_ == str:
            return self.to_string(**kwargs)
        raise ValueError(f"Supported types are int, str, and float: {type_}")

    ############################################################
    # Misc
    ############################################################
    def nunique(self, dropna: bool = True) -> pd.Series:
        """Returns number of unique elements per column of data frame.

        Args:
            dropna: Whether none values are counted or not.

        Returns:
            Number of unique elements per column.
        """
        operator = CountDistinctOperator if dropna else CountDistinctNullOperator
        return self.apply_aggregation_operator(operator).fillna(0)  # type: ignore

    def set_filters(self, filters: Sequence[FilterLike]) -> "DataFrame":
        """Removes filters of series."""
        return self.copy(filters=filters)

    def reset_filters(self) -> "DataFrame":
        """Removes all filters."""
        return self.set_filters([])

    def reindex(self, index: BaseIndex) -> "DataFrame":
        """Updates index of series."""
        return self.copy(index=index)

    def reset_index(self) -> "DataFrame":
        """Resets index to default and drop original index."""
        return self.reindex(RangeIndex())

    def drop(self, labels: Union[str, List[str]]) -> "DataFrame":
        """Drop labels from columns.

        Args:
            labels: Name of columns to drop.

        Returns:
            DataFrame without given columns.
        """
        if isinstance(labels, str):
            labels = [labels]

        labels_set = self.verify_columns_contained(labels)

        data = OrderedDict([(key, value) for key, value in self._data.items() if key not in labels_set])
        return self.copy(data=data)

    def sort_values(self, by: Union[str, List[str]], ascending: Union[bool, List[bool]] = True) -> "DataFrame":
        """Sorts data frame by given columns.

        Args:
            by: Name or list of names of columns to sort by.
            ascending: Sort ascending or descending. Specify list for multiple sort orders.

        Returns:
            DataFrame with OrderByColumns set.
        """
        if isinstance(by, str):
            by = [by]
        if isinstance(ascending, bool):
            ascending = [ascending] * len(by)

        if len(by) != len(ascending):
            raise ValueError(
                f"Parameters 'by' and 'ascending' need to have the same length: {len(by)} != {len(ascending)}"
            )

        return self.copy(
            order_by_columns=[
                OrderByColumn(query=self[by_column].data.query_string, ascending=ascending_column)
                for by_column, ascending_column in zip(by, ascending)
            ]
        )

    ############################################################
    # Low-Level Functions
    ############################################################
    def apply_unary_operator(self, operator: Type[UnaryPQLOperator], **kwargs: Any) -> "DataFrame":
        """Applies given unary operator to data frame.

        Args:
            operator: Operator to apply.

        Returns:
            DataFrame with operator applied.
        """
        return self.copy(
            data=OrderedDict(
                [(name, series.copy(data=operator(series.data, **kwargs))) for name, series in self._data.items()]
            )
        )

    def apply_binary_operator(
        self,
        other: Union["DataFrame", Series, pd.Series, ScalarValue],
        operator: Type[BinaryPQLOperator],
        reverse: bool = False,
    ) -> "DataFrame":
        """Applies given binary operator to data frame and exports result.

        Args:
            other: Other operand to apply binary operator on.
            operator: Operator to apply.
            reverse: If true order of operands is reversed.

        Returns:
            DataFrame with operator applied.
        """
        if isinstance(other, Series) or is_scalar_value(other):
            return self._apply_binary_operator_to_series(other, operator, reverse=reverse)  # type: ignore

        if isinstance(other, DataFrame):
            return self._apply_binary_operator_to_data_frame(other, operator, reverse=reverse)

        if isinstance(other, pd.Series):
            return self._apply_binary_operator_to_pd_series(other, operator, reverse=reverse)

        raise TypeError(f"Data type {type(other)} not supported.")

    def apply_binary_operator_dunder(
        self,
        other: Union["DataFrame", Series, pd.Series, ScalarValue],
        operator: Type[BinaryPQLOperator],
        reverse: bool = False,
    ) -> "DataFrame":
        """Combines data frame with other by applying function for each column for dunder methods."""
        try:
            return self.apply_binary_operator(other, operator, reverse=reverse)
        except TypeError:
            return NotImplemented

    def apply_aggregation_operator(self, operator: Type[UnaryPQLOperator], **kwargs: Any) -> pd.Series:
        """Applies given aggregation operator to data frame and exports result.

        Args:
            operator: Operator to apply.

        Returns:
            Series with operator applied.
        """
        pd_data_frame = self.apply_unary_operator(operator, **kwargs).to_pandas()

        # If data frame is empty, create empty series
        if pd_data_frame.shape[0] == 0:
            pd_data_frame = pd.concat([pd_data_frame, pd.DataFrame({col: [None] for col in self.columns})])

        # Convert data frame to series, use empty series if data frame has no columns
        pd_series = pd_data_frame.iloc[0, :] if pd_data_frame.shape[1] > 0 else pd.Series(dtype="object")
        return pd_series.fillna(np.nan)

    def _apply_binary_operator_to_series(
        self, other: Union[Series, ScalarValue], operator: Type[BinaryPQLOperator], reverse: bool = False
    ) -> "DataFrame":
        """Combines data frame with other series or scalar by applying function for each column."""
        return self.copy(
            data=OrderedDict(
                [
                    (name, series.apply_binary_operator(other, operator, reverse=reverse))
                    for name, series in self._data.items()
                ]
            )
        )

    def _apply_binary_operator_to_pd_series(
        self, other: pd.Series, operator: Type[BinaryPQLOperator], reverse: bool = False
    ) -> "DataFrame":
        """Combines data frame with other data frame by applying function for each column."""
        if set(self.columns) != set(other.index):
            raise ValueError(
                f"Can't combine data frame with series with different columns/index: "
                f"{self.columns} != {other.index.values}"
            )
        return self.copy(
            data=OrderedDict(
                [
                    (
                        name,
                        series.apply_binary_operator(convert_numpy_to_python(other[name]), operator, reverse=reverse),
                    )
                    for name, series in self._data.items()
                ]
            )
        )

    def _apply_binary_operator_to_data_frame(
        self, other: "DataFrame", operator: Type[BinaryPQLOperator], reverse: bool = False
    ) -> "DataFrame":
        """Combines data frame with other data frame by applying function for each column."""
        if set(self.columns) != set(other.columns):
            raise ValueError("Can't combine two data frames with different columns.")
        return self.copy(
            data=OrderedDict(
                [
                    (name, series.apply_binary_operator(other[name], operator, reverse=reverse))
                    for name, series in self._data.items()
                ]
            )
        )

    def copy(
        self,
        data: Optional[typing.OrderedDict[str, Union[Series]]] = None,
        index: Optional[BaseIndex] = None,
        filters: Optional[FiltersLike] = None,
        order_by_columns: Optional[List[OrderByColumn]] = None,
        saola_connector: Optional[SaolaConnector] = None,
    ) -> "DataFrame":
        """Copies given data frame  and overrides properties given as parameters."""
        data = data if data is not None else self._data.copy()
        index = index if index is not None else self.index
        filters = filters if filters is not None else self.filters
        order_by_columns = order_by_columns if order_by_columns is not None else list(self.order_by_columns)
        saola_connector = saola_connector if saola_connector is not None else self._saola_connector

        # Update series to match new filters and index of data frame
        updated_data: MutableMapping[str, SeriesLike] = {
            name: series.reindex(index).set_filters(filters) for name, series in data.items()
        }
        return self.__class__(
            data=updated_data,
            index=index,
            filters=filters,
            order_by_columns=order_by_columns,
            saola_connector=saola_connector,
        )

    def _convert_to_series(self, name: str, series: Any) -> Series:
        """Converts data to Series."""
        if isinstance(series, Series):
            return series

        if isinstance(series, (str, PQLColumn, PQLOperator)):
            return self._series_class(
                data=series,
                index=self.index,
                filters=self.filters,
                name=name,
                saola_connector=self._saola_connector,
            )

        raise TypeError(f"Data type {type(series)} not supported.")

    def verify_columns_contained(self, columns: List[str]) -> typing.Set[str]:
        """Verifies whether the dataframe contains columns.

        Args:
            columns: List of columns to verify

        Returns:
            Set of verified column names
        """
        labels_set = set(columns)
        labels_diff = labels_set.difference(self.columns)
        if labels_diff:
            raise ValueError(f"Labels {sorted(labels_diff)} are not contained in columns.")
        return labels_set
