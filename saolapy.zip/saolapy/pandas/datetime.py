from typing import Mapping, Type

from saolapy.operator.base import UnaryPQLOperator
from saolapy.operator.datetime import (
    CalendarWeekOperator,
    DayOfWeekOperator,
    DayOperator,
    HoursOperator,
    MinutesOperator,
    MonthOperator,
    QuarterOperator,
    RoundDayOperator,
    RoundHourOperator,
    RoundMinuteOperator,
    RoundMonthOperator,
    RoundQuarterOperator,
    RoundSecondOperator,
    RoundWeekOperator,
    RoundYearOperator,
    SecondsOperator,
    YearOperator,
)
from saolapy.pandas.series import Series


class DatetimeMethods:
    """Class that provides datetime methods to series."""

    FREQUENCY_MAPPING: Mapping[str, Type[UnaryPQLOperator]] = {
        "Y": RoundYearOperator,
        "A": RoundYearOperator,
        "Q": RoundQuarterOperator,
        "M": RoundMonthOperator,
        "W": RoundWeekOperator,
        "D": RoundDayOperator,
        "H": RoundHourOperator,
        "T": RoundMinuteOperator,
        "min": RoundMinuteOperator,
        "S": RoundSecondOperator,
    }

    def __init__(self, series: "Series"):
        """Initializes Datetime Methods object for series.

        Args:
            series: Series to be used.
        """
        self._series = series

    @property
    def year(self) -> "Series":
        """Returns a series with year of date.

        Applies [YEAR operator](https://docs.celonis.com/en/year.html) to column.

        Returns:
            A series containing year of given date.
        """
        return self._series.apply_unary_operator(YearOperator)

    @property
    def quarter(self) -> "Series":
        """Returns a series with quarter of date.

        Applies [QUARTER operator](https://docs.celonis.com/en/quarter.html) to column.

        Returns:
            A series containing quarter of given date.
        """
        return self._series.apply_unary_operator(QuarterOperator)

    @property
    def month(self) -> "Series":
        """Returns a series with month of date.

        Applies [MONTH operator](https://docs.celonis.com/en/month.html) to column.

        Returns:
            A series containing month of given date.
        """
        return self._series.apply_unary_operator(MonthOperator)

    @property
    def week_of_year(self) -> "Series":
        """Returns a series with week of year of date.

        Applies [CALENDAR_WEEK operator](https://docs.celonis.com/en/calendar_week.html) to column.

        Returns:
            A series containing week of year of given date.
        """
        return self._series.apply_unary_operator(CalendarWeekOperator)

    @property
    def day_of_week(self) -> "Series":
        """Returns a series with day of week of date.

        Applies [DAY_OF_WEEK operator](https://docs.celonis.com/en/day_of_week.html) to column.

        Returns:
            A series containing day of week of given date.
        """
        return self._series.apply_unary_operator(DayOfWeekOperator)

    @property
    def day(self) -> "Series":
        """Returns a series with day of date.

        Applies [DAY operator](https://docs.celonis.com/en/day.html) to column.

        Returns:
            A series containing day of given date.
        """
        return self._series.apply_unary_operator(DayOperator)

    @property
    def hour(self) -> "Series":
        """Returns a series with hour of date.

        Applies [HOURS operator](https://docs.celonis.com/en/hours.html) to column.

        Returns:
            A series containing hour of given date.
        """
        return self._series.apply_unary_operator(HoursOperator)

    @property
    def minute(self) -> "Series":
        """Returns a series with minute of date.

        Applies [MINUTES operator](https://docs.celonis.com/en/minutes.html) to column.

        Returns:
            A series containing minute of given date.
        """
        return self._series.apply_unary_operator(MinutesOperator)

    @property
    def second(self) -> "Series":
        """Returns a series with seconds of date.

        Applies [SECONDS operator](https://docs.celonis.com/en/seconds.html) to column.

        Returns:
            A series containing seconds of given date.
        """
        return self._series.apply_unary_operator(SecondsOperator)

    def round(self, freq: str) -> "Series":
        """Rounds datetime series to given frequency.

        Args:
            freq: Frequency to round datetime to. Supported frequencies are:
                Y, A: year
                Q: quarter
                M: month
                W: week
                D: day
                H: hour
                T, min: minute
                S: second

        Returns:
            A series rounded to given frequency.
        """
        if freq not in DatetimeMethods.FREQUENCY_MAPPING:
            raise ValueError(
                f"Frequency {freq} not supported. Supported frequencies are {DatetimeMethods.FREQUENCY_MAPPING.keys()}"
            )

        return self._series.apply_unary_operator(DatetimeMethods.FREQUENCY_MAPPING[freq])
