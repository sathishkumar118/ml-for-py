from typing import Any, List, Optional, Sequence

from saolapy.operator import PQLOperator
from saolapy.pandas import ImmutableObject
from saolapy.pql.base import PQLFilter
from saolapy.saola_connector import SaolaConnector
from saolapy.types import FilterLike


class Filters(ImmutableObject):
    """Collection of filters to filter Series or DataFrame."""

    _pql_filters: List[PQLFilter]
    _saola_connector: Optional[SaolaConnector]

    def __init__(
        self, pql_filters: Optional[Sequence[FilterLike]] = None, saola_connector: Optional[SaolaConnector] = None
    ):
        """Initializes filters.

        Args:
            pql_filters: PQL filters to use.
            saola_connector: Saola connector used to export data.
        """
        self._set_attr("_pql_filters", [self._convert_to_pql_filter(filter_) for filter_ in pql_filters or []])
        self._set_attr("_saola_connector", saola_connector)

    @property
    def pql_filters(self) -> List[PQLFilter]:
        """Returns list of pql filters."""
        return list(self._pql_filters)

    @property
    def saola_connector(self) -> SaolaConnector:
        """Returns saola connector of series."""
        if not self._saola_connector:
            raise ValueError("Can't export data as there is no `saola_connector` set.")
        return self._saola_connector

    @property
    def filter_expression(self) -> Optional[str]:
        """Returns filter expression for given filters."""
        filter_expressions = [
            filter_expression
            for filter_ in self.pql_filters
            for filter_expression in self.saola_connector.convert_filter_to_expressions(filter_)
        ]
        return f"( {' ) AND ( '.join(filter_expressions)} )" if len(filter_expressions) > 0 else None

    def __eq__(self, other: Any) -> bool:
        if not isinstance(other, Filters):
            return False

        filter_strings_self = set(f.query for f in self.pql_filters)
        filter_strings_other = set(f.query for f in other.pql_filters)
        return filter_strings_self == filter_strings_other

    def __repr__(self) -> str:
        return repr(self.pql_filters)

    def __str__(self) -> str:
        return str(self.pql_filters)

    def _repr_pretty_(self, p: Any, cycle: bool) -> None:
        p.text(str(self) if not cycle else "...")

    def add(self, filter_: FilterLike) -> "Filters":
        """Adds filter to pql filters."""
        return self.copy(pql_filters=self.pql_filters + [self._convert_to_pql_filter(filter_)])

    def copy(
        self, pql_filters: Optional[Sequence[FilterLike]] = None, saola_connector: Optional[SaolaConnector] = None
    ) -> "Filters":
        """Returns copy of given filters."""
        pql_filters = pql_filters if pql_filters is not None else self.pql_filters
        saola_connector = saola_connector if saola_connector is not None else self._saola_connector

        return self.__class__(pql_filters=pql_filters, saola_connector=saola_connector)

    def _convert_to_pql_filter(self, filter_: FilterLike) -> PQLFilter:
        """Converts input to PQLFilter."""
        if isinstance(filter_, str):
            return PQLFilter(query=filter_)
        if isinstance(filter_, PQLOperator):
            return PQLFilter(query=f"FILTER {filter_.query_string};")
        if isinstance(filter_, PQLFilter):
            return filter_
        raise TypeError(f"Data type {type(filter_)} not supported as filter.")
