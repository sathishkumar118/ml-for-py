from typing import Any, List, Type

import pandas as pd

from saolapy.operator.aggregation import (
    AvgOperator,
    CountDistinctOperator,
    CountOperator,
    MaxOperator,
    MedianOperator,
    MinOperator,
    ModeOperator,
    ProductOperator,
    QuantileOperator,
    StandardDeviationOperator,
    SumOperator,
    VarianceOperator,
)
from saolapy.operator.base import UnaryPQLOperator
from saolapy.pandas.data_frame import DataFrame
from saolapy.pandas.index import Index, MultiIndex


class GroupByAggregationMethods:
    """Class that provides group by aggregation methods to dataframe."""

    def __init__(self, data_frame: "DataFrame", group_by_columns: List[str]):
        """Initializes GroupByAggregationMethods object for dataframe.

        Args:
            data_frame: DataFrame to be used.
            group_by_columns: The table to which the aggregation result should be pulled.
        """
        self._data_frame: "DataFrame" = data_frame
        self._data_frame.verify_columns_contained(group_by_columns)
        self._index: MultiIndex = self.__preprocess_group_by_columns(group_by_columns)

    def mean(self) -> "pd.DataFrame":
        """Applies AVG operator to given dataframe.

        Applies [AVG operator](https://docs.celonis.com/en/avg.html) to column.

        Returns:
            DataFrame after applying AVG operator.
        """
        return self._apply_group_by_operator(AvgOperator)

    def sum(self) -> "pd.DataFrame":
        """Applies SUM operator to given dataframe.

        Applies [SUM operator](https://docs.celonis.com/en/sum.html) to column.

        Returns:
            DataFrame after applying SUM operator.
        """
        return self._apply_group_by_operator(SumOperator)

    def product(self) -> "pd.DataFrame":
        """Applies PRODUCT operator to given series.

        Applies [PRODUCT operator](https://docs.celonis.com/en/product.html) to column.

        Returns:
            DataFrame after applying PRODUCT operator.
        """
        return self._apply_group_by_operator(ProductOperator)

    def count(self) -> "pd.DataFrame":
        """Applies COUNT operator to given dataframe.

        Applies [COUNT operator](https://docs.celonis.com/en/count.html) to column.

        Returns:
            DataFrame after applying COUNT operator.
        """
        return self._apply_group_by_operator(CountOperator)

    def count_distinct(self) -> "pd.DataFrame":
        """Applies PU_COUNT_DISTINCT operator to given dataframe.

        Applies [PU_COUNT_DISTINCT operator](https://docs.celonis.com/en/count-distinct.html) to column.

        Returns:
            DataFrame after applying PU_COUNT_DISTINCT operator.
        """
        return self._apply_group_by_operator(CountDistinctOperator)

    def min(self) -> "pd.DataFrame":
        """Applies MIN operator to given dataframe.

        Applies [MIN operator](https://docs.celonis.com/en/min.html) to column.

        Returns:
            DataFrame after applying MIN operator.
        """
        return self._apply_group_by_operator(MinOperator)

    def max(self) -> "pd.DataFrame":
        """Applies MAX operator to given dataframe.

        Applies [MAX operator](https://docs.celonis.com/en/max.html) to column.

        Returns:
            DataFrame after applying MAX operator.
        """
        return self._apply_group_by_operator(MaxOperator)

    def median(self) -> "pd.DataFrame":
        """Applies MEDIAN operator to given dataframe.

        Applies [MEDIAN operator](https://docs.celonis.com/en/median.html) to column.

        Returns:
            DataFrame after applying MEDIAN operator.
        """
        return self._apply_group_by_operator(MedianOperator)

    def mode(self) -> "pd.DataFrame":
        """Applies MODE operator to given dataframe.

        Applies [MODE operator](https://docs.celonis.com/en/mode.html) to column.

        Returns:
            DataFrame after applying MODE operator.
        """
        return self._apply_group_by_operator(ModeOperator)

    def std(self) -> "pd.DataFrame":
        """Applies STDEV operator to given dataframe.

        Applies [STDEV operator](https://docs.celonis.com/en/stdev.html) to column.

        Returns:
            DataFrame after applying STDEV operator.
        """
        return self._apply_group_by_operator(StandardDeviationOperator)

    def quantile(self, quantile: float) -> "pd.DataFrame":
        """Applies QUANTILE operator to given dataframe.

        Applies [QUANTILE operator](https://docs.celonis.com/en/quantile.html) to column.

        Returns:
            DataFrame after applying QUANTILE operator.
        """
        return self._apply_group_by_operator(QuantileOperator, quantile=quantile)

    def var(self) -> "pd.DataFrame":
        """Applies VAR operator to given dataframe.

        Applies [VAR operator](https://docs.celonis.com/en/var.html) to column.

        Returns:
            DataFrame after applying VAR operator.
        """
        return self._apply_group_by_operator(VarianceOperator)

    def _apply_group_by_operator(self, operator: Type[UnaryPQLOperator], **kwargs: Any) -> "pd.DataFrame":
        """Applies given aggregation operator to dataframe grouped by columns.

        Args:
            operator: Aggregation operator to apply.

        Returns:
            DataFrame with operator applied.
        """
        self._data_frame = self._data_frame.reindex(index=self._index).drop(self._index.names)
        return self._data_frame.apply_unary_operator(operator, **kwargs).to_pandas()

    def __preprocess_group_by_columns(self, group_by_columns: List[str]) -> MultiIndex:
        """Maps group by column names to MultiIndex.

        Returns:
            MultiIndex
        """
        return MultiIndex(levels=[Index(name=col, data=self._data_frame[col].data) for col in group_by_columns])
