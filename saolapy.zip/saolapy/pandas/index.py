import typing
from abc import ABC, abstractmethod
from collections import OrderedDict
from typing import Any, List

from saolapy.operator import PQLOperator
from saolapy.operator.base import QueryStringPQLOperator
from saolapy.operator.range import RangeOperator
from saolapy.pandas import ImmutableObject
from saolapy.pql.base import PQLColumn
from saolapy.types import ColumnLike


class BaseIndex(ImmutableObject, ABC):
    """Base class for SaolaPy indices."""

    @property
    @abstractmethod
    def query_columns(self) -> List[PQLColumn]:
        """Returns PQL column of index."""

    @property
    def query_column_names(self) -> List[str]:
        """Returns list of query column names."""
        return [col.name for col in self.query_columns]

    @property
    def query_column_queries(self) -> List[str]:
        """Returns list of query column queries."""
        return [col.query for col in self.query_columns]

    def __eq__(self, other: Any) -> bool:
        """Returns whether index matches other index."""
        if not isinstance(other, BaseIndex):
            return False
        return self.query_column_queries == other.query_column_queries


class Index(BaseIndex):
    """One-dimensional PQL Index."""

    _data: PQLOperator
    _name: str

    def __init__(
        self,
        data: ColumnLike,
        name: str = "Index",
    ):
        """Initializes index.

        Args:
            data: Data to be used. Can be either PQL query string, PQLColumn, or PQLOperator.
            name: Name of object. Defaults to 'Index'.
        """
        self._set_attr("_data", data if isinstance(data, PQLOperator) else QueryStringPQLOperator(data))
        self._set_attr("_name", name)

    @property
    def data(self) -> PQLOperator:
        """Returns data of index."""
        return self._data

    @property
    def name(self) -> str:
        """Returns name of index."""
        return self._name

    @property
    def query_columns(self) -> List[PQLColumn]:
        """Returns PQL columns of index."""
        if self.data.is_boolean:
            raise ValueError(
                f"Can't create query for boolean operator: '{self.data}'. "
                "Boolean operators can only be used as filters."
            )
        return [PQLColumn(query=self.data.query_string, name=self.name)]

    def __repr__(self) -> str:
        """Returns string representation of index."""
        properties: typing.OrderedDict[str, Any] = OrderedDict()
        properties["name"] = self.name
        properties["data"] = self.data.query_string

        return ImmutableObject.object_str(self.__class__.__name__, properties)

    def _repr_pretty_(self, p: Any, cycle: bool) -> None:
        p.text(str(self) if not cycle else "...")


class MultiIndex(BaseIndex):
    """Multi-dimensional PQL Index."""

    _levels: List[Index]

    def __init__(
        self,
        levels: List[Index],
    ):
        """Initializes multi index.

        Args:
            levels: Indices to be used as multi index.
        """
        self._verify_levels(levels)
        self._set_attr("_levels", levels)

    @property
    def levels(self) -> List[Index]:
        """Returns levels of multi index."""
        return self._levels

    @property
    def names(self) -> List[str]:
        """Names of levels in multi index."""
        return [index.name for index in self.levels]

    @property
    def nlevels(self) -> int:
        """Returns number of levels of multi index."""
        return len(self.levels)

    @property
    def query_columns(self) -> List[PQLColumn]:
        """Returns PQL columns of multi index."""
        return [column for level in self.levels for column in level.query_columns]

    def __repr__(self) -> str:
        """Returns string representation of multi index."""
        properties: typing.OrderedDict[str, Any] = OrderedDict()
        properties["indices"] = self.levels

        return ImmutableObject.object_str(self.__class__.__name__, properties)

    def _repr_pretty_(self, p: Any, cycle: bool) -> None:
        p.text(str(self) if not cycle else "...")

    def _verify_levels(self, levels: List[Index]) -> None:
        if len(levels) == 0:
            raise ValueError("Need to set at least one index for multi index.")

        level_names = [level.name for level in levels]
        if len(set(level_names)) != len(level_names):
            raise ValueError(f"Index names have to be unique for multi index: {level_names}")


class RangeIndex(Index):
    """Immutable index implementing a monotonically increasing integer range."""

    _start: int
    _step: int

    def __init__(
        self,
        start: int = 0,
        step: int = 1,
        name: str = "Index",
    ):
        """Initializes RangeIndex.

        Args:
            start: Start of range, defaults to 0.
            step: Step size of range, defaults to 1.
            name: Name of object.
        """
        super().__init__(data=RangeOperator(start=start, step=step), name=name)
        self._set_attr("_start", start)
        self._set_attr("_step", step)

    def __repr__(self) -> str:
        """Returns string representation of range index."""
        properties: typing.OrderedDict[str, Any] = OrderedDict()
        properties["name"] = self.name
        properties["start"] = self._start
        properties["step"] = self._step

        return ImmutableObject.object_str(self.__class__.__name__, properties)

    def _repr_pretty_(self, p: Any, cycle: bool) -> None:
        p.text(str(self) if not cycle else "...")
