import re
from typing import Any, Type

from saolapy.operator.pull_up_aggregation import (
    PullUpAvgOperator,
    PullUpCountDistinctOperator,
    PullUpCountOperator,
    PullUpMaxOperator,
    PullUpMedianOperator,
    PullUpMinOperator,
    PullUpModeOperator,
    PullUpOperator,
    PullUpProductOperator,
    PullUpStandardDeviationOperator,
    PullUpSumOperator,
)
from saolapy.pandas.series import Series


class PullUpAggregationMethods:
    """Class that provides pull up aggregation methods to series."""

    def __init__(self, series: "Series", target_table: str):
        """Initializes PullUpAggregationMethods object for series.

        Args:
            series: Series to be used.
            target_table: The table to which the aggregation result should be pulled.
        """
        self._series = series
        self._target_table = self._preprocess_target_table(target_table)

    def mean(self) -> "Series":  # type: ignore
        """Applies PU_AVG operator to given series.

        Applies [PU_AVG operator](https://docs.celonis.com/en/pu_avg.html) to column.

        Returns:
            Series after applying PU_AVG operator.
        """
        return self._apply_pull_up_operator(PullUpAvgOperator)

    def sum(self) -> "Series":  # type: ignore
        """Applies PU_SUM operator to given series.

        Applies [PU_SUM operator](https://docs.celonis.com/en/pu_sum.html) to column.

        Returns:
            Series after applying PU_SUM operator.
        """
        return self._apply_pull_up_operator(PullUpSumOperator)

    def product(self) -> "Series":  # type: ignore
        """Applies PU_PRODUCT operator to given series.

        Applies [PU_PRODUCT operator](https://docs.celonis.com/en/pu_product.html) to column.

        Returns:
            Series after applying PU_PRODUCT operator.
        """
        return self._apply_pull_up_operator(PullUpProductOperator)

    def count(self) -> "Series":  # type: ignore
        """Applies PU_COUNT operator to given series.

        Applies [PU_COUNT operator](https://docs.celonis.com/en/pu_count.html) to column.

        Returns:
            Series after applying PU_COUNT operator.
        """
        return self._apply_pull_up_operator(PullUpCountOperator)

    def count_distinct(self) -> "Series":  # type: ignore
        """Applies PU_COUNT_DISTINCT operator to given series.

        Applies [PU_COUNT_DISTINCT operator](https://docs.celonis.com/en/pu_count_distinct.html) to column.

        Returns:
            Series after applying PU_COUNT_DISTINCT operator.
        """
        return self._apply_pull_up_operator(PullUpCountDistinctOperator)

    def min(self) -> "Series":  # type: ignore
        """Applies PU_MIN operator to given series.

        Applies [PU_MIN operator](https://docs.celonis.com/en/pu_min.html) to column.

        Returns:
            Series after applying PU_MIN operator.
        """
        return self._apply_pull_up_operator(PullUpMinOperator)

    def max(self) -> "Series":  # type: ignore
        """Applies PU_MAX operator to given series.

        Applies [PU_MAX operator](https://docs.celonis.com/en/pu_max.html) to column.

        Returns:
            Series after applying PU_MAX operator.
        """
        return self._apply_pull_up_operator(PullUpMaxOperator)

    def median(self) -> "Series":  # type: ignore
        """Applies PU_MEDIAN operator to given series.

        Applies [PU_MEDIAN operator](https://docs.celonis.com/en/pu_median.html) to column.

        Returns:
            Series after applying PU_MEDIAN operator.
        """
        return self._apply_pull_up_operator(PullUpMedianOperator)

    def mode(self) -> "Series":  # type: ignore
        """Applies PU_MODE operator to given series.

        Applies [PU_MODE operator](https://docs.celonis.com/en/pu_mode.html) to column.

        Returns:
            Series after applying PU_MODE operator.
        """
        return self._apply_pull_up_operator(PullUpModeOperator)

    def std(self) -> "Series":  # type: ignore
        """Applies PU_STDEV operator to given series.

        Applies [PU_STDEV operator](https://docs.celonis.com/en/pu_stdev.html) to column.

        Returns:
            Series after applying PU_STDEV operator.
        """
        return self._apply_pull_up_operator(PullUpStandardDeviationOperator)

    def _apply_pull_up_operator(self, operator: Type[PullUpOperator], **kwargs: Any) -> "Series":
        """Applies given pull up operator to series.

        Args:
            operator: PullUp operator to apply.

        Returns:
            Series with operator applied.
        """
        return self._series.apply_unary_operator(
            operator,
            target_table=self._target_table,
            filter_expression=self._series.filters.filter_expression,
            **kwargs
        )

    def _preprocess_target_table(self, target_table: str) -> str:
        """Checks if target table is a DOMAIN_TABLE or CONSTANT and adds quotes if not."""
        if not re.match(r"DOMAIN_TABLE\s*\(.*\)|CONSTANT\s*\(\s*\)", target_table, re.IGNORECASE):
            return '"' + target_table.strip('"') + '"'
        return target_table
