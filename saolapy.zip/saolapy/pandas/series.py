import typing
from collections import OrderedDict
from typing import TYPE_CHECKING, Any, List, Optional, Tuple, Type, Union, cast

import numpy as np
import pandas as pd

from saolapy.operator import PQLOperator
from saolapy.operator.aggregation import (
    AvgOperator,
    CountDistinctNullOperator,
    CountDistinctOperator,
    CountNullOperator,
    CountOperator,
    IsUniqueOperator,
    MaxOperator,
    MedianOperator,
    MinOperator,
    ModeOperator,
    ProductOperator,
    QuantileOperator,
    StandardDeviationOperator,
    SumOperator,
    VarianceOperator,
)
from saolapy.operator.arithmetic import AbsOperator, AddOperator, DivideOperator, FloorDivisionOperator, InverseOperator
from saolapy.operator.arithmetic import IsNullOperator as ArithmeticIsNullOperator
from saolapy.operator.arithmetic import ModuloOperator, MultiplyOperator, PowerOperator, RoundOperator, SubtractOperator
from saolapy.operator.base import BinaryPQLOperator, QueryStringPQLOperator, UnaryPQLOperator
from saolapy.operator.boolean import (
    AndOperator,
    BetweenOperator,
    EqualsOperator,
    GreaterEqualsOperator,
    GreaterThanOperator,
    IsInOperator,
    IsNullOperator,
    LowerEqualsOperator,
    LowerThanOperator,
    NotEqualsOperator,
    NotOperator,
    OrOperator,
)
from saolapy.operator.data_type import ToDateOperator, ToFloatOperator, ToIntOperator, ToStringOperator
from saolapy.pandas import ImmutableObject
from saolapy.pandas.filters import Filters
from saolapy.pandas.index import BaseIndex, RangeIndex
from saolapy.pandas.util import verify_compatibility
from saolapy.pql.base import PQL, OrderByColumn, PQLColumn, PQLFilter
from saolapy.pql.formatter import OrderByColumnFormatter
from saolapy.saola_connector import SaolaConnector
from saolapy.types import ColumnLike, FiltersLike, NumericValue, ScalarValue, is_scalar_value

if TYPE_CHECKING:
    from saolapy.pandas.datetime import DatetimeMethods
    from saolapy.pandas.pull_up_aggregation import PullUpAggregationMethods
    from saolapy.pandas.string import StringMethods


class Series(ImmutableObject):
    """One dimensional PQL Series."""

    _data: PQLOperator
    _index: BaseIndex
    _filters: Filters
    _order_by_columns: List[OrderByColumn]
    _name: str  # type: ignore  # pylint: disable=used-before-assignment
    _saola_connector: Optional[SaolaConnector]

    def __init__(
        self,
        data: ColumnLike,
        index: Optional[BaseIndex] = None,
        filters: Optional[FiltersLike] = None,
        order_by_columns: Optional[List[OrderByColumn]] = None,
        name: str = "Series",
        saola_connector: Optional[SaolaConnector] = None,
    ):
        """Initializes series.

        Args:
            data: Data to be used. Can be either PQL query string, PQLColumn, or PQLOperator.
            index: Index to be used. Default is RangeIndex.
            filters: Filters to be used. Default is none.
            order_by_columns: OrderByColumns to be used to sort series. Default is none.
            name: Name of series.
            saola_connector: Saola connector used to export data.
        """
        self._set_attr("_data", data if isinstance(data, PQLOperator) else QueryStringPQLOperator(data))
        self._set_attr("_index", index or RangeIndex())
        self._set_attr(
            "_filters", filters if isinstance(filters, Filters) else Filters(filters, saola_connector=saola_connector)
        )
        self._set_attr("_order_by_columns", order_by_columns or [])
        self._set_attr("_name", name)
        self._set_attr("_saola_connector", saola_connector)

        if self._saola_connector is not None and not self.data.is_boolean:
            self._saola_connector.verify_query(self.query)

    ############################################################
    # Attributes
    ############################################################
    @property
    def data(self) -> PQLOperator:
        """Returns data of series."""
        return self._data

    @property
    def index(self) -> BaseIndex:
        """Returns index of series."""
        return self._index

    @property
    def filters(self) -> Filters:
        """Returns filters of series."""
        return self._filters

    @property
    def order_by_columns(self) -> List[OrderByColumn]:
        """Returns order by columns of series."""
        return self._order_by_columns

    @property
    def name(self) -> str:
        """Returns name of series."""
        return self._name

    @property
    def saola_connector(self) -> SaolaConnector:
        """Returns saola connector of series."""
        if not self._saola_connector:
            raise ValueError(
                "Can't export data as there is no `saola_connector` or `data_model` set. "
                "For more information see our quickstart tutorial::\n\n"
                "https://celonis.github.io/pycelonis/2.4.1/tutorials/executed/05_saolapy/01_saolapy_quickstart/#21-basics"  # pylint: disable=line-too-long
            )
        return self._saola_connector

    ############################################################
    # Query Properties
    ############################################################
    @property
    def query(self) -> PQL:
        """Returns PQL query of series."""
        return PQL() + self.index.query_columns + self.query_column + self.query_filters + self.query_order_by_columns

    @property
    def query_column(self) -> PQLColumn:
        """Returns PQL column of series."""
        if self.data.is_boolean:
            raise ValueError(
                f"Can't create query for boolean operator: '{self.data}'. "
                "Boolean operators can only be used as filters."
            )
        return PQLColumn(query=self.data.query_string, name=self.name)

    @property
    def query_filters(self) -> List[PQLFilter]:
        """Returns filters of series."""
        return self.filters.pql_filters

    @property
    def query_order_by_columns(self) -> List[OrderByColumn]:
        """Returns order by columns of series."""
        return self.order_by_columns

    ############################################################
    # Accessor Functions
    ############################################################
    def __getitem__(self, key: Union["Series", PQLOperator]) -> "Series":
        """Adds filter to series."""
        if isinstance(key, Series):
            verify_compatibility(self.index, key.index, self.filters, key.filters)
            return self.copy(filters=self.filters.add(key.data))

        if isinstance(key, PQLOperator):
            return self.copy(filters=self.filters.add(key))

        raise TypeError("Key needs to be of type Series or PQLOperator.")

    ############################################################
    # String Representation
    ############################################################
    def __repr__(self) -> "str":  # type: ignore
        """Returns string representation of object."""
        properties: typing.OrderedDict[str, Any] = OrderedDict()
        properties["data"] = self.data
        properties["index"] = self.index
        properties["filters"] = self.filters
        properties["order_by_columns"] = self.order_by_columns
        properties["name"] = self.name
        properties["saola_connector"] = self._saola_connector

        return ImmutableObject.object_str(self.__class__.__name__, properties)

    def __str__(self) -> "str":  # type: ignore
        """Returns string representation of object."""
        max_length = 50

        properties: typing.OrderedDict[str, Any] = OrderedDict()
        properties["data"] = self.data.query_string
        properties["index"] = self.index
        properties["filters"] = [
            ImmutableObject.shorten_string(filter_.query, max_length) for filter_ in self.filters.pql_filters
        ]
        properties["order_by_columns"] = [
            ImmutableObject.shorten_string(OrderByColumnFormatter().format(col), max_length)
            for col in self.order_by_columns
        ]
        properties["name"] = self.name

        return ImmutableObject.object_str(self.__class__.__name__, properties)

    def _repr_pretty_(self, p: Any, cycle: bool) -> None:
        p.text(str(self) if not cycle else "...")

    ############################################################
    # Export Functions
    ############################################################
    def head(self, n: int = 5) -> pd.Series:
        """Returns the first n rows based on position as pandas Series.

        Args:
            n: Number of rows to return.

        Returns:
            First n rows as pandas Series.
        """
        return self.to_pandas(limit=n)

    def to_pandas(
        self, distinct: Optional[bool] = None, limit: Optional[int] = None, offset: Optional[int] = None
    ) -> pd.Series:
        """Exports data of given query using saola connector."""
        exported_data = self.saola_connector.export_data(self.query, distinct=distinct, limit=limit, offset=offset)
        exported_data = exported_data.set_index(self.index.query_column_names, drop=True)
        return exported_data[self.name]

    ############################################################
    # Dimensionality Functions
    ############################################################
    @property
    def ndim(self) -> int:
        """Returns an int representing the number of axes."""
        return 1

    @property
    def nrows(self) -> int:
        """Returns an int representing the number of rows of this series."""
        aggregation_result = self.apply_aggregation_operator(CountNullOperator)
        return cast(int, aggregation_result if not np.isnan(aggregation_result) else 0)  # type: ignore

    @property
    def size(self) -> int:
        """Returns an int representing the number of elements in this series."""
        return self.nrows

    @property
    def shape(self) -> Tuple[int]:
        """Returns a tuple representing the shape of this series."""
        return (self.nrows,)

    @property
    def empty(self) -> bool:
        """Returns whether series is empty."""
        return self.size == 0

    ############################################################
    # Method Classes
    ############################################################
    @property
    def str(self) -> "StringMethods":
        """Return string methods object containing all string-specific methods."""
        from saolapy.pandas.string import StringMethods

        return StringMethods(self)

    @property
    def dt(self) -> "DatetimeMethods":
        """Return datetime methods object containing all datetime-specific methods."""
        from saolapy.pandas.datetime import DatetimeMethods

        return DatetimeMethods(self)

    def pu(self, target_table: "str") -> "PullUpAggregationMethods":  # type: ignore
        """Return pull up aggregation methods object containing all pull-up methods.

        Args:
            target_table: The table to which the aggregation result should be pulled.

        Returns:
            PullUpAggregationMethods object.
        """
        from saolapy.pandas.pull_up_aggregation import PullUpAggregationMethods

        return PullUpAggregationMethods(self, target_table=target_table)

    ############################################################
    # Arithmetic Functions
    ############################################################
    def add(self, other: Union["Series", NumericValue]) -> "Series":
        """Return addition of series and other.

        Applies [ADD operator](https://docs.celonis.com/en/add.html) to column.

        Args:
            other: Series or numeric scalar to be added.

        Returns:
            The result of the operation.
        """
        return self.apply_binary_operator(other, AddOperator)

    def __add__(self, other: Union["Series", NumericValue]) -> "Series":
        return self.apply_binary_operator_dunder(other, AddOperator)

    def __radd__(self, other: Union["Series", NumericValue]) -> "Series":
        return self.apply_binary_operator_dunder(other, AddOperator, reverse=True)

    def sub(self, other: Union["Series", NumericValue]) -> "Series":
        """Return subtraction of series and other.

        Applies [SUB operator](https://docs.celonis.com/en/sub.html) to column.

        Args:
            other: Series or numeric scalar to be subtracted.

        Returns:
            The result of the operation.
        """
        return self.apply_binary_operator(other, SubtractOperator)

    def __sub__(self, other: Union["Series", NumericValue]) -> "Series":
        return self.apply_binary_operator_dunder(other, SubtractOperator)

    def __rsub__(self, other: Union["Series", NumericValue]) -> "Series":
        return self.apply_binary_operator_dunder(other, SubtractOperator, reverse=True)

    def mul(self, other: Union["Series", NumericValue]) -> "Series":
        """Return multiplication of series and other.

        Applies [MULT operator](https://docs.celonis.com/en/mult.html) to column.

        Args:
            other: Series or numeric scalar to be multiplied.

        Returns:
            The result of the operation.
        """
        return self.apply_binary_operator(other, MultiplyOperator)

    def __mul__(self, other: Union["Series", NumericValue]) -> "Series":
        return self.apply_binary_operator_dunder(other, MultiplyOperator)

    def __rmul__(self, other: Union["Series", NumericValue]) -> "Series":
        return self.apply_binary_operator_dunder(other, MultiplyOperator, reverse=True)

    def div(self, other: Union["Series", NumericValue]) -> "Series":
        """Return division of series and other.

        Applies [DIV operator](https://docs.celonis.com/en/div.html) to column.

        Args:
            other: Series or numeric scalar to be divided.

        Returns:
            The result of the operation.
        """
        return self.apply_binary_operator(other, DivideOperator)

    def __truediv__(self, other: Union["Series", NumericValue]) -> "Series":
        return self.apply_binary_operator_dunder(other, DivideOperator)

    def __rtruediv__(self, other: Union["Series", NumericValue]) -> "Series":
        return self.apply_binary_operator_dunder(other, DivideOperator, reverse=True)

    def floordiv(self, other: Union["Series", NumericValue]) -> "Series":
        """Return floor division of series and other.

        Applies [FLOOR operator](https://docs.celonis.com/en/floor.html) and
        [DIV operator](https://docs.celonis.com/en/div.html) to column.

        Args:
            other: Series or numeric scalar to be floor divided.

        Returns:
            The result of the operation.
        """
        return self.apply_binary_operator(other, FloorDivisionOperator)

    def __floordiv__(self, other: Union["Series", NumericValue]) -> "Series":
        return self.apply_binary_operator_dunder(other, FloorDivisionOperator)

    def __rfloordiv__(self, other: Union["Series", NumericValue]) -> "Series":
        return self.apply_binary_operator_dunder(other, FloorDivisionOperator, reverse=True)

    def mod(self, other: Union["Series", NumericValue]) -> "Series":
        """Return modulo of series and other.

        Applies [MODULO operator](https://docs.celonis.com/en/modulo.html) to column.

        Args:
            other: Series or numeric scalar to be modulo'd.

        Returns:
            The result of the operation.
        """
        return self.apply_binary_operator(other, ModuloOperator)

    def __mod__(self, other: Union["Series", NumericValue]) -> "Series":
        return self.apply_binary_operator_dunder(other, ModuloOperator)

    def __rmod__(self, other: Union["Series", NumericValue]) -> "Series":
        return self.apply_binary_operator_dunder(other, ModuloOperator, reverse=True)

    def pow(self, other: Union["Series", NumericValue]) -> "Series":
        """Return the series raised to the power of the other.

        Applies [POWER operator](https://docs.celonis.com/en/power.html) to column.

        Args:
            other: Series or numeric scalar to be the exponent.

        Returns:
            The result of the operation.
        """
        return self.apply_binary_operator(other, PowerOperator)

    def __pow__(self, other: Union["Series", NumericValue]) -> "Series":
        return self.apply_binary_operator_dunder(other, PowerOperator)

    def __rpow__(self, other: Union["Series", NumericValue]) -> "Series":
        return self.apply_binary_operator_dunder(other, PowerOperator, reverse=True)

    def abs(self) -> "Series":
        """Return the series with the absolute value of its elements.

        Applies [ABS operator](https://docs.celonis.com/en/abs.html) to column.
        """
        return self.copy(data=AbsOperator(self.data))

    def round(self, decimals: int = 0) -> "Series":
        """Round series to given number of decimals.

        Applies [ROUND operator](https://docs.celonis.com/en/round.html) to column.
        """
        return self.apply_unary_operator(RoundOperator, decimals=decimals)

    ############################################################
    # Boolean Functions
    ############################################################
    @property
    def is_unique(self) -> bool:
        """Return boolean if values in the object are unique."""
        aggregation_result = self.apply_aggregation_operator(IsUniqueOperator)
        return np.isnan(aggregation_result) or aggregation_result == 1  # type: ignore

    @property
    def hasnans(self) -> bool:
        """Return boolean if there are any null values in the object."""
        aggregation_result = self.apply_unary_operator(ArithmeticIsNullOperator).apply_aggregation_operator(SumOperator)
        return np.isnan(aggregation_result) or aggregation_result != 0  # type: ignore

    def lt(self, other: Union["Series", ScalarValue]) -> "Series":
        """Return a Series of booleans indicating whether each element is less than the other.

        Applies [LOWER_THAN operator](https://docs.celonis.com/en/comparison-operators.html) to column.

        Args:
            other: Series or scalar to be compared.

        Returns:
            The result of the operation.
        """
        return self.apply_binary_operator(other, LowerThanOperator)

    def __lt__(self, other: Union["Series", ScalarValue]) -> "Series":
        return self.apply_binary_operator_dunder(other, LowerThanOperator)

    def le(self, other: Union["Series", ScalarValue]) -> "Series":
        """Return a Series of booleans indicating whether each element is less than or equal to the other.

        Applies [LOWER_EQUALS operator](https://docs.celonis.com/en/comparison-operators.html) to column.

        Args:
            other: Series or scalar to be compared.

        Returns:
            The result of the operation.
        """
        return self.apply_binary_operator(other, LowerEqualsOperator)

    def __le__(self, other: Union["Series", ScalarValue]) -> "Series":
        return self.apply_binary_operator_dunder(other, LowerEqualsOperator)

    def eq(self, other: Union["Series", ScalarValue]) -> "Series":
        """Return a Series of booleans indicating whether each element is equal to the other.

        Applies [EQUALS operator](https://docs.celonis.com/en/comparison-operators.html) to column.

        Args:
            other: Series or scalar to be compared.

        Returns:
            The result of the operation.
        """
        return self.apply_binary_operator(other, EqualsOperator)

    def __eq__(self, other: Any) -> "Series":  # type: ignore
        if isinstance(other, Series) or is_scalar_value(other):
            return self.apply_binary_operator_dunder(other, EqualsOperator)
        raise TypeError(f"Data type {type(other)} not supported.")

    def ne(self, other: Union["Series", ScalarValue]) -> "Series":
        """Return a Series of booleans indicating whether each element is not equal to the other.

        Applies [NOT_EQUALS operator](https://docs.celonis.com/en/comparison-operators.html) to column.

        Args:
            other: Series or scalar to be compared.

        Returns:
            The result of the operation.
        """
        return self.apply_binary_operator(other, NotEqualsOperator)

    def __ne__(self, other: Any) -> "Series":  # type: ignore
        if isinstance(other, Series) or is_scalar_value(other):
            return self.apply_binary_operator_dunder(other, NotEqualsOperator)
        raise TypeError(f"Data type {type(other)} not supported.")

    def ge(self, other: Union["Series", ScalarValue]) -> "Series":
        """Return a Series of booleans indicating whether each element is greater than or equal to the other.

        Applies [GREATER_EQUALS operator](https://docs.celonis.com/en/comparison-operators.html) to column.

        Args:
            other: Series or scalar to be compared.

        Returns:
            The result of the operation.
        """
        return self.apply_binary_operator(other, GreaterEqualsOperator)

    def __ge__(self, other: Union["Series", ScalarValue]) -> "Series":
        return self.apply_binary_operator_dunder(other, GreaterEqualsOperator)

    def gt(self, other: Union["Series", ScalarValue]) -> "Series":
        """Return a Series of booleans indicating whether each element is greater than the other.

        Applies [GREATER_THAN operator](https://docs.celonis.com/en/comparison-operators.html) to column.

        Args:
            other: Series or scalar to be compared.

        Returns:
            The result of the operation.
        """
        return self.apply_binary_operator(other, GreaterThanOperator)

    def __gt__(self, other: Union["Series", ScalarValue]) -> "Series":
        return self.apply_binary_operator_dunder(other, GreaterThanOperator)

    def __and__(self, other: "Series") -> "Series":
        """Return a Series of booleans indicating the result of the logical AND operation.

        Applies [AND operator](https://docs.celonis.com/en/and.html) to column.

        Args:
            other: Series to be combined.

        Returns:
            The result of the operation.
        """
        return self.apply_binary_operator(other, AndOperator)

    def __or__(self, other: "Series") -> "Series":
        """Return a Series of booleans indicating the result of the logical OR operation.

        Applies [OR operator](https://docs.celonis.com/en/or.html) to column.

        Args:
            other: Series to be combined.

        Returns:
            The result of the operation.
        """
        return self.apply_binary_operator_dunder(other, OrOperator)

    def __invert__(self) -> "Series":
        """Return a Series of booleans indicating the result of the logical NOT operation.

        Returns:
            The result of the operation.
        """
        operator = NotOperator if self.data.is_boolean else InverseOperator
        return self.apply_unary_operator(operator)  # type: ignore

    def isnull(self) -> "Series":
        """Return a boolean same-sized Series indicating if the values are null.

        Applies [IS NULL operator](https://docs.celonis.com/en/is-null.html) to column.

        Returns:
            A Series of masked bool values for each element that indicates whether an element is a null value.
        """
        return self.apply_unary_operator(IsNullOperator)

    def isin(self, values: List[Union["Series", ScalarValue]]) -> "Series":
        """Returns whether elements of series are in values.

        Applies [IN operator](https://docs.celonis.com/en/in.html) to column.

        Args:
            values: List of values to test.

        Returns:
            The result of the operation.
        """
        if not isinstance(values, list):
            raise TypeError(f"Only lists are allowed and not {type(values)}")

        converted_values = [value.data if isinstance(value, Series) else value for value in values]
        return self.apply_unary_operator(IsInOperator, values=converted_values)

    def between(self, left: ScalarValue, right: ScalarValue) -> "Series":
        """Return boolean Series equivalent to left <= series <= right.

        Applies [BETWEEN operator](https://docs.celonis.com/en/between.html) to column.

        Args:
            left: Left boundary.
            right: Right boundary.

        Returns:
            The result of the operation.
        """
        return self.apply_unary_operator(BetweenOperator, left=left, right=right)

    ############################################################
    # Aggregation Functions
    ############################################################
    def mean(self) -> ScalarValue:
        """Return the mean of the values.

        Applies [AVG operator](https://docs.celonis.com/en/avg.html) to column.

        Returns:
            Mean of series values.
        """
        return self.apply_aggregation_operator(AvgOperator)

    def median(self) -> ScalarValue:
        """Return the median of the values.

        Applies [MEDIAN operator](https://docs.celonis.com/en/median.html) to column.

        Returns:
            Median of series values.
        """
        return self.apply_aggregation_operator(MedianOperator)

    def quantile(self, q: float = 0.5) -> ScalarValue:
        """Return the quantile of the values.

        Applies [QUANTILE operator](https://docs.celonis.com/en/quantile.html) to column.

        Args:
            q: Quantile to compute. 0 <= q <= 1.

        Returns:
            Quantile of series values.
        """
        return self.apply_aggregation_operator(QuantileOperator, quantile=q)

    def mode(self) -> "Series":
        """Return a series containing a single mode of the values.

        Applies [MODE operator](https://docs.celonis.com/en/mode.html) to column.
        For multi-modal input, i.e. there are several result candidates, the element with the smallest value is chosen.
        For elements of type STRING, the smallest value is determined by its lexicographical order

        Returns:
            Mode of series values.
        """
        return self.apply_unary_operator(ModeOperator).to_pandas()

    def max(self) -> ScalarValue:
        """Return the max of the values.

        Applies [MAX operator](https://docs.celonis.com/en/max.html) to column.

        Returns:
            Max of series values.
        """
        return self.apply_aggregation_operator(MaxOperator)

    def min(self) -> ScalarValue:
        """Return the min of the values.

        Applies [MIN operator](https://docs.celonis.com/en/min.html) to column.

        Returns:
            Min of series values.
        """
        return self.apply_aggregation_operator(MinOperator)

    def sum(self) -> ScalarValue:
        """Return the sum of the values.

        Applies [SUM operator](https://docs.celonis.com/en/sum.html) to column.

        Returns:
            Sum of series values.
        """
        return self.apply_aggregation_operator(SumOperator)

    def product(self) -> ScalarValue:
        """Return the product of the non-null values. Null values are skipped.

        Applies [PRODUCT operator](https://docs.celonis.com/en/product.html) to column.
        In case of an overflow the result will be null.

        Returns:
            Product of series values.
        """
        return self.apply_aggregation_operator(ProductOperator)

    def count(self) -> ScalarValue:
        """Return the number of non-null values.

        Applies [COUNT operator](https://docs.celonis.com/en/count.html) to column.

        Returns:
            Number of non-null values.
        """
        return self.apply_aggregation_operator(CountOperator)

    def var(self) -> ScalarValue:
        """Return the variance of the given series using the n-1 method. Null values are ignored.

        Applies [VAR operator](https://docs.celonis.com/en/var.html) to column.

        Returns:
            Variance of series.
        """
        return self.apply_aggregation_operator(VarianceOperator)

    def std(self) -> ScalarValue:
        """Return the standard deviation of the given series using the n-1 method. Null values are ignored.

        Applies [STDEV operator](https://docs.celonis.com/en/stdev.html) to column.

        Returns:
            Standard deviation of series.
        """
        return self.apply_aggregation_operator(StandardDeviationOperator)

    ############################################################
    # Type Conversion Functions
    ############################################################
    def to_int(self) -> "Series":
        """Converts given series to int.

        Applies [TO_INT operator](https://docs.celonis.com/en/to_int.html) to column.
        """
        return self.apply_unary_operator(ToIntOperator)

    def to_float(self) -> "Series":
        """Converts given series to float.

        Applies [TO_FLOAT operator](https://docs.celonis.com/en/to_float.html) to column.
        """
        return self.apply_unary_operator(ToFloatOperator)

    def to_string(self, format_: Optional["str"] = None) -> "Series":  # type: ignore
        """Converts given series to string.

        Applies [TO_STRING operator](https://docs.celonis.com/en/to_string.html) to column.

        Args:
            format_: Optional, defines how dates are converted to string.

        Returns:
            Series converted to string.
        """
        return self.apply_unary_operator(ToStringOperator, format_=format_)

    def to_date(self, format_: "str") -> "Series":  # type: ignore
        """Converts given series to date.

        Applies [TO_DATE operator](https://docs.celonis.com/en/to_date.html) to column.

        Args:
            format_: Defines how strings are converted to date.

        Returns:
            Series converted to date.
        """
        return self.apply_unary_operator(ToDateOperator, format_=format_)

    def astype(self, type_: Type[Union["str", int, float]], **kwargs: Any) -> "Series":  # type: ignore
        """Converts given series to type.

        Args:
            type_: Type to convert to. Supported types are str, int, float.
            **kwargs: Passed to conversion function.

        Returns:
            Converted series.
        """
        if type_ == int:
            return self.to_int()
        if type_ == float:
            return self.to_float()
        if type_ == str:
            return self.to_string(**kwargs)
        raise ValueError(f"Supported types are int, str, and float: {type_}")

    ############################################################
    # Misc
    ############################################################
    def dropna(self) -> "Series":
        """Return Series with filter for null values.

        Returns:
            A Series with null values filtered out.
        """
        return self[~self.isnull()]

    def unique(self) -> np.ndarray:
        """Returns all distinct elements of series."""
        return self.to_pandas(distinct=True).values

    def nunique(self, dropna: bool = True) -> int:
        """Returns number of unique elements in series.

        Args:
            dropna: Whether none values are counted or not.

        Returns:
            Number of unique elements in series.
        """
        operator = CountDistinctOperator if dropna else CountDistinctNullOperator
        aggregation_result = self.apply_aggregation_operator(operator)  # type: ignore
        return cast(int, aggregation_result if not np.isnan(aggregation_result) else 0)  # type: ignore

    def value_counts(
        self, normalize: bool = False, sort: bool = True, ascending: bool = False, dropna: bool = True
    ) -> "Series":
        """Return a Series containing counts of unique values.

        Args:
            normalize: If True the relative frequencies of the unique values will be returned.
            sort: Sort by frequencies.
            ascending: Sort in ascending order.
            dropna: Don't include counts of Null.

        Returns:
            A Series of counts of unique values.
        """
        count_name = f"COUNT_{self.name}"

        query = self.query + PQLColumn(name=count_name, query=CountNullOperator(self.data).query_string)

        if sort:
            query.order_by_columns = [
                OrderByColumn(query=CountNullOperator(self.data).query_string, ascending=ascending)
            ]

        exported_df = self.saola_connector.export_data(query)

        if dropna:
            exported_df = exported_df.dropna()

        if normalize:
            value_count_sum = exported_df[count_name].sum()
            exported_df[count_name] = exported_df[count_name] / value_count_sum

        return exported_df.set_index(self.name, drop=True).loc[:, count_name]

    def set_filters(self, filters: FiltersLike) -> "Series":
        """Removes filters of series."""
        return self.copy(filters=filters)

    def reset_filters(self) -> "Series":
        """Removes all filters."""
        return self.set_filters([])

    def reindex(self, index: BaseIndex) -> "Series":
        """Updates index of series and drops old index."""
        return self.copy(index=index)

    def reset_index(self) -> "Series":
        """Resets index to default."""
        return self.reindex(RangeIndex())

    def sort_values(self, ascending: bool = True) -> "Series":
        """Sorts series.

        Args:
            ascending: Sort ascending or descending.

        Returns:
            Series with OrderByColumns set.
        """
        return self.copy(order_by_columns=[OrderByColumn(query=self.data.query_string, ascending=ascending)])

    ############################################################
    # Low-Level Functions
    ############################################################
    def apply_unary_operator(self, operator: Type[UnaryPQLOperator], **kwargs: Any) -> "Series":
        """Applies given unary operator to series.

        Args:
            operator: Operator to apply.

        Returns:
            Series with operator applied.
        """
        return self.copy(data=operator(self.data, **kwargs))

    def apply_binary_operator(
        self,
        other: Union["Series", ScalarValue],
        operator: Type[BinaryPQLOperator],
        reverse: bool = False,
        **kwargs: Any,
    ) -> "Series":
        """Applies given binary operator to series.

        Args:
            other: Other operand to apply binary operator on.
            operator: Operator to apply.
            reverse: If true order of operands is reversed.

        Returns:
            Series with operator applied.
        """
        if not isinstance(other, Series) and not is_scalar_value(other):
            raise TypeError(f"Data type {type(other)} not supported.")

        if isinstance(other, Series):
            verify_compatibility(self.index, other.index, self.filters, other.filters)

        other_data = other.data if isinstance(other, Series) else other

        if reverse:
            return self.copy(data=operator(other_data, self.data, **kwargs))
        return self.copy(data=operator(self.data, other_data, **kwargs))

    def apply_binary_operator_dunder(
        self, other: Union["Series", ScalarValue], operator: Type[BinaryPQLOperator], reverse: bool = False
    ) -> "Series":
        """Combines series with the other for dunder methods."""
        try:
            return self.apply_binary_operator(other, operator, reverse=reverse)
        except TypeError:
            return NotImplemented

    def apply_aggregation_operator(self, operator: Type[UnaryPQLOperator], **kwargs: Any) -> ScalarValue:
        """Applies given aggregation operator to series and exports result.

        Args:
            operator: Operator to apply.

        Returns:
            Result of aggregation.
        """
        series = self.apply_unary_operator(operator, **kwargs)
        pd_series = series.to_pandas()

        if pd_series.shape[0] == 0:
            return np.nan

        aggregation_result = pd_series.iloc[0]
        return aggregation_result if aggregation_result is not None else np.nan

    def copy(
        self,
        data: Optional[PQLOperator] = None,
        index: Optional[BaseIndex] = None,
        filters: Optional[FiltersLike] = None,
        order_by_columns: Optional[List[OrderByColumn]] = None,
        name: Optional["str"] = None,  # type: ignore
        saola_connector: Optional[SaolaConnector] = None,
    ) -> "Series":
        """Copies given series and overrides properties given as parameters."""
        data = data if data is not None else self.data
        index = index if index is not None else self.index
        filters = filters if filters is not None else self.filters
        order_by_columns = order_by_columns if order_by_columns is not None else list(self.order_by_columns)
        name = name if name is not None else self.name
        saola_connector = saola_connector if saola_connector is not None else self._saola_connector

        return self.__class__(
            data=data,
            index=index,
            filters=filters,
            order_by_columns=order_by_columns,
            name=name,
            saola_connector=saola_connector,
        )
