from typing import Union

from saolapy.operator.string import (
    ConcatenateOperator,
    ContainsOperator,
    EndsWithOperator,
    LengthOperator,
    LowerOperator,
    LStripOperator,
    ReplaceOperator,
    RStripOperator,
    StartsWithOperator,
    StringIndexOperator,
    StripOperator,
    SubstringOperator,
    UpperOperator,
)
from saolapy.pandas.series import Series
from saolapy.types import ScalarValue


class StringMethods:
    """Class that provides string methods to series."""

    def __init__(self, series: "Series"):
        """Initializes String Methods object for series.

        Args:
            series: Series to be used.
        """
        self._series = series

    def __getitem__(self, key: Union[int, slice]) -> "Series":
        """Returns substring of string series based on key.

        Applies [SUBSTRING operator](https://docs.celonis.com/en/substring.html) to column.
        """
        if isinstance(key, slice):  # Get substring
            if key.step is not None:
                raise ValueError(f"Setting step size for slice '{key}' is not supported.")
            return self._series.apply_unary_operator(SubstringOperator, start=key.start, stop=key.stop)

        if isinstance(key, int):  # Get character at index
            return self._series.apply_unary_operator(StringIndexOperator, index=key)

        raise TypeError("Only integers or slices are supported for indexing.")

    def __add__(self, other: Union["Series", str]) -> "Series":
        """Return concatenation of series and other.

        Applies [CONCAT operator](https://docs.celonis.com/en/concat.html) to column.

        Args:
            other: Series or string to be concatenated.

        Returns:
            The result of the operation.
        """
        return self._series.apply_binary_operator_dunder(other, ConcatenateOperator)

    def __radd__(self, other: Union["Series", str]) -> "Series":
        return self._series.apply_binary_operator_dunder(other, ConcatenateOperator, reverse=True)

    def len(self) -> "Series":
        """Return a series containing the length of each string.

        Applies [LEN operator](https://docs.celonis.com/en/len.html) to column.

        Returns:
            A series containing the length of each string.
        """
        return self._series.apply_unary_operator(LengthOperator)

    def lower(self) -> "Series":
        """Return a series with all strings converted to lowercase.

        Applies [LOWER operator](https://docs.celonis.com/en/lower.html) to column.

        Returns:
            A series with all strings converted to lowercase.
        """
        return self._series.apply_unary_operator(LowerOperator)

    def upper(self) -> "Series":
        """Return a series with all strings converted to uppercase.

        Applies [UPPER operator](https://docs.celonis.com/en/upper.html) to column.

        Returns:
            A series with all strings converted to uppercase.
        """
        return self._series.apply_unary_operator(UpperOperator)

    def lstrip(self) -> "Series":
        """Return a series with leading whitespace removed from each string.

        Applies [LTRIM operator](https://docs.celonis.com/en/ltrim.html) to column.

        Returns:
            A series with leading whitespace removed from each string.
        """
        return self._series.apply_unary_operator(LStripOperator)

    def rstrip(self) -> "Series":
        """Return a series with trailing whitespace removed from each string.

        Applies [RTRIM operator](https://docs.celonis.com/en/rtrim.html) to column.

        Returns:
            A series with trailing whitespace removed from each string.
        """
        return self._series.apply_unary_operator(RStripOperator)

    def strip(self) -> "Series":
        """Return a series with leading and trailing whitespace removed from each string.

        Applies [RTRIM operator](https://docs.celonis.com/en/rtrim.html) and
        [LTRIM operator](https://docs.celonis.com/en/ltrim.html) to column.

        Returns:
            A series with leading and trailing whitespace removed from each string.
        """
        return self._series.apply_unary_operator(StripOperator)

    def startswith(self, pattern: str) -> "Series":
        """Return a boolean series indicating if each string starts with the specified pattern.

        Applies [LIKE operator](https://docs.celonis.com/en/like.html) to column.

        Args:
            pattern: The string pattern to check.

        Returns:
            A boolean series indicating if each string starts with the specified pattern.
        """
        return self._series.apply_unary_operator(StartsWithOperator, pattern=pattern)

    def endswith(self, pattern: str) -> "Series":
        """Return a boolean series indicating if each string ends with the specified pattern.

        Applies [LIKE operator](https://docs.celonis.com/en/like.html) to column.

        Args:
            pattern: The string pattern to check.

        Returns:
            A boolean series indicating if each string ends with the specified pattern.
        """
        return self._series.apply_unary_operator(EndsWithOperator, pattern=pattern)

    def contains(self, pattern: str) -> "Series":
        """Return a boolean series indicating if the input pattern is contained in each string.

        Applies [LIKE operator](https://docs.celonis.com/en/like.html) to column.

        Args:
            pattern: String pattern to search for.

        Returns:
            A boolean series indicating if the pattern is contained in each string.
        """
        return self._series.apply_unary_operator(ContainsOperator, pattern=pattern)

    def replace(self, to_replace: Union["Series", ScalarValue], value: Union["Series", ScalarValue]) -> "Series":
        """Return a series with all occurrences of to_replace replaced by the replacement value.

        Applies [REPLACE operator](https://docs.celonis.com/en/replace.html) to column.

        Args:
            to_replace: The string pattern to search for.
            value: The string to replace to_replace with.

        Returns:
            A series with all occurrences of search_pattern replaced by the replacement string.
        """
        return self._series.apply_unary_operator(
            ReplaceOperator,
            to_replace=to_replace.data if isinstance(to_replace, Series) else to_replace,
            value=value.data if isinstance(value, Series) else value,
        )
