from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from saolapy.pandas.filters import Filters
    from saolapy.pandas.index import BaseIndex


def verify_compatibility(index1: "BaseIndex", index2: "BaseIndex", filters1: "Filters", filters2: "Filters") -> None:
    """Verifies compatibility between indices and filters."""
    if index1 != index2:
        raise ValueError(f"Indices do not match: {index1} != {index2}.")

    if filters1 != filters2:
        raise ValueError(f"Filters do not match: {filters1} != {filters2}.")
