"""Module to interact with PQL queries."""
try:
    from pydantic.v1 import BaseModel  # type: ignore
except ImportError:
    from pydantic import BaseModel  # type: ignore


class SaolaPyBaseModel(BaseModel):
    """Base Model for any SaolaPy object."""

    class Config:
        """Basic configuration used by SaolaPy PyDantic models."""

        allow_population_by_field_name = True
        arbitrary_types_allowed = True
