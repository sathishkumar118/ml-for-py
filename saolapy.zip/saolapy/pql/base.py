"""Module to interact with PQL queries.

This module contains class to interact with PQL queries including columns and filters.

Typical usage example:

    ```python
    query = PQL(distinct=True)
    query += PQLColumn(name="column", query='"TABLE"."COLUMN"')
    query += PQLFilter(query='FILTER "TABLE"."COLUMN" = 1;')
    query += OrderByColumn(query='"TABLE"."COLUMN"', ascending=False)
    ```
"""
import collections.abc
from typing import Iterable, List, Optional, Union

from saolapy.pql import SaolaPyBaseModel
from saolapy.pql.formatter import PQLFormatter

try:
    from pydantic.v1 import Field, NonNegativeInt  # type: ignore
except ImportError:
    from pydantic import Field, NonNegativeInt  # type: ignore


class PQLColumn(SaolaPyBaseModel):
    """Class representing PQL column of OLAP table.

    Attributes:
        name: Name of the column.
        query: PQL query of the column.
    """

    name: str
    query: str


class PQLFilter(SaolaPyBaseModel):
    """Class representing PQL filter.

    Attributes:
        query: Query of PQL filter. Needs to have format 'FILTER CONDITION;'.
    """

    query: str


class OrderByColumn(SaolaPyBaseModel):
    """Class representing order by column used to order results of query.

    Attributes:
        query: Query of order by column.
        ascending: Whether results should be sorted ascending or descending. Default True.
    """

    query: str
    ascending: bool = True


class PQL(SaolaPyBaseModel):
    """Class representing PQL query that can be used for data export.

    Attributes:
        columns: PQLColumn objects of query representing columns of query.
        filters: PQLFilter objects of query filtering result.
        order_by_columns: OrderByColumns used to sort result. First column is most important and last column least
            important.
        distinct: If true, result only contains distinct rows and no duplicates.
        limit: Output rows are limited to `limit` rows. If None, all rows are returned.
        offset: Output skips `offset` first rows. If None, no rows are skipped.
    """

    columns: List[PQLColumn] = Field(default_factory=list)
    filters: List[PQLFilter] = Field(default_factory=list)
    order_by_columns: List[OrderByColumn] = Field(default_factory=list)

    distinct: bool = False
    limit: Optional[NonNegativeInt] = None  # pylint: disable=no-member
    offset: Optional[NonNegativeInt] = None  # pylint: disable=no-member

    _pql_formatter: PQLFormatter = PQLFormatter()

    @property
    def queries(self) -> List[str]:
        """Returns list of string queries that can be used to export data.

        Returns:
            List of query strings.
        """
        return self._pql_formatter.format(self)

    def add(
        self,
        obj: Union[PQLColumn, PQLFilter, Iterable[Union[PQLColumn, PQLFilter, OrderByColumn]]],
    ) -> None:
        """Adds object to PQL object depending on object type.

        Args:
            obj: Object to add to PQL query. Can be either PQLColumn, PQLFilter, OrderByColumn, or a list of these
                objects.

        Raises:
            TypeError: Raised if object type does not match supported types.
        """
        if isinstance(obj, PQLColumn):
            self.columns.append(obj)  # pylint: disable=no-member
        elif isinstance(obj, PQLFilter):
            self.filters.append(obj)  # pylint: disable=no-member
        elif isinstance(obj, OrderByColumn):
            self.order_by_columns.append(obj)  # pylint: disable=no-member
        elif isinstance(obj, collections.abc.Iterable) and not isinstance(obj, str):
            for nested_obj in obj:
                self.add(nested_obj)  # type: ignore
        else:
            raise TypeError("Added object needs to be either of type PQLColumn, PQLFilter, or OrderByColumn")

    def __add__(
        self,
        value: Union[PQLColumn, PQLFilter, Iterable[Union[PQLColumn, PQLFilter, OrderByColumn]]],
    ) -> "PQL":
        self.add(value)
        return self
