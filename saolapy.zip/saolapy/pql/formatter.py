"""Module contains functionality for formatting PQL objects as PQL string."""
import typing
from typing import List, Optional

if typing.TYPE_CHECKING:
    from saolapy.pql.base import PQL, OrderByColumn, PQLColumn


class PQLColumnFormatter:
    """Class to format PQLColumn as string."""

    def format(self, column: "PQLColumn") -> str:
        """Formats given PQLColumn.

        Args:
            column: Column to format.

        Returns:
            String containing formatted column.
        """
        return f'{column.query} AS "{column.name}"'


class OrderByColumnFormatter:
    """Class to format OrderByColumn as string."""

    def format(self, column: "OrderByColumn") -> str:
        """Formats given OrderByColumn.

        Args:
            column: Column to format.

        Returns:
            String containing formatted column.
        """
        return f"{column.query} {'ASC' if column.ascending else 'DESC'}"


class PQLFormatter:
    """Class to format PQL query as string."""

    def __init__(
        self,
        pql_column_formatter: Optional[PQLColumnFormatter] = None,
        order_by_column_formatter: Optional[OrderByColumnFormatter] = None,
    ):
        """Initializes PQLFormatter.

        Args:
            pql_column_formatter: Formatter to use for PQLColumn.
            order_by_column_formatter:  Formatter to use for OrderByColumn.
        """
        self.pql_column_formatter = pql_column_formatter or PQLColumnFormatter()
        self.order_by_column_formatter = order_by_column_formatter or OrderByColumnFormatter()

    def format(self, query: "PQL") -> List[str]:
        """Formats PQL query.

        Args:
            query: Query to format.

        Returns:
            Formatted PQL query as list of strings.
        """
        return [f.query for f in query.filters] + [self._table_string(query)]

    def _table_string(self, query: "PQL") -> str:
        return (
            f"TABLE ({self._distinct_string(query.distinct)}\n"
            f"{self._columns_string(query.columns)}\n"
            f")\n"
            f"{self._order_by_string(query.order_by_columns)}"
            f"{self._limit_string(query.limit)}{self._offset_string(query.offset)}".strip() + ";"
        )

    def _distinct_string(self, distinct: bool) -> str:
        return "DISTINCT" if distinct else ""

    def _columns_string(self, pql_columns: List["PQLColumn"]) -> str:
        return ",\n".join(self.pql_column_formatter.format(column) for column in pql_columns)

    def _order_by_string(self, order_by_columns: List["OrderByColumn"]) -> str:
        if order_by_columns:
            column_string = ", ".join(self.order_by_column_formatter.format(column) for column in order_by_columns)
            return f"ORDER BY {column_string}\n"
        return ""

    def _limit_string(self, limit: Optional[int]) -> str:
        return f"LIMIT {limit} " if limit is not None else "NOLIMIT "

    def _offset_string(self, offset: Optional[int]) -> str:
        return f"OFFSET {offset} " if offset is not None else ""
