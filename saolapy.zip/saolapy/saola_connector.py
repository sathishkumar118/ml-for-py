from abc import ABC, abstractmethod
from typing import List, Optional

import pandas as pd

from saolapy.errors import DataExportFailedError
from saolapy.pql.base import PQL, PQLFilter


class SaolaConnector(ABC):
    """Interface for saola connector."""

    def export_data(
        self, query: PQL, distinct: Optional[bool] = None, limit: Optional[int] = None, offset: Optional[int] = None
    ) -> pd.DataFrame:
        """Exports given PQL as data frame with error handling."""
        if distinct is not None:
            query.distinct = distinct
        if limit is not None:
            query.limit = limit
        if offset is not None:
            query.offset = offset

        try:
            exported_data = self._export_data(query)
        except Exception as e:
            raise DataExportFailedError(
                f"Data export failed for query:\n{query.queries}\n\n{getattr(e, 'message', str(e))}"
            ) from e

        if limit is not None:
            # This is necessary due to LIMIT bug in PQL where an additional row is exported
            exported_data = exported_data.head(limit)
        return exported_data

    def verify_query(self, query: PQL) -> None:
        """Verifies given query."""

    @abstractmethod
    def convert_filter_to_expressions(self, filter_: PQLFilter) -> List[str]:
        """Converts given pql filter to conditional expressions.

        Args:
            filter_: PQL filter to convert.

        Returns:
            Conditional expressions resulting from pql filter.
        """

    @abstractmethod
    def _export_data(self, query: PQL) -> pd.DataFrame:
        """Exports given PQL as data frame."""
