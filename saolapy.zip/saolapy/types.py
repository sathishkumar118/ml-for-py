from datetime import datetime
from typing import TYPE_CHECKING, Any, Sequence, Union

import numpy as np

from saolapy.operator import PQLOperator
from saolapy.pql.base import PQLColumn, PQLFilter

if TYPE_CHECKING:
    from saolapy.pandas.filters import Filters
    from saolapy.pandas.series import Series


ScalarValue = Union[str, int, float, datetime]
NumericValue = Union[int, float]

ColumnLike = Union[str, PQLColumn, PQLOperator]
FilterLike = Union[str, PQLFilter, PQLOperator]
FiltersLike = Union["Filters", Sequence[FilterLike]]

SeriesLike = Union["Series", ColumnLike]


def is_scalar_value(value: Any) -> bool:
    """Returns whether input is scalar value (str, int, float, datetime)."""
    if isinstance(value, bool):
        return False
    return isinstance(value, (str, int, float, datetime))


def convert_numpy_to_python(
    value: Union[np.float64, np.uint32, np.int16, np.int32, np.int64, np.datetime64, ScalarValue]
) -> ScalarValue:
    """Converts input value from numpy data type to python primitive data type."""
    if is_scalar_value(value):
        return value  # type: ignore

    if isinstance(value, (np.float64, np.uint32, np.int16, np.int32, np.int64, np.datetime64)):
        return value.item()

    raise TypeError(
        f"Type {type(value)} not supported for conversion. Supported types are: np.float64, np.uint32, np.int16, "
        f"np.int32, np.int64, np.datetime64, str, int, float, datetime"
    )
